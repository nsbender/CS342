CREATE VIEW USER_OPERATOR_COMMENTS AS select u.name, o.name, c.comment$
from   sys.obj$ o, sys.operator$ op, sys.com$ c, sys.user$ u
where  o.obj# = op.obj# and c.obj# = op.obj# and u.user# = o.owner#
       and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_OPERATOR_COMMENTS IS 'Comments for user-defined operators'
/
COMMENT ON COLUMN SYS.USER_OPERATOR_COMMENTS.OWNER IS 'Owner of the user-defined operator'
/
COMMENT ON COLUMN SYS.USER_OPERATOR_COMMENTS.OPERATOR_NAME IS 'Name of the user-defined operator'
/
COMMENT ON COLUMN SYS.USER_OPERATOR_COMMENTS.COMMENTS IS 'Comment for the user-defined operator'
/

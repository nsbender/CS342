CREATE VIEW USER_SUBSCRIBED_TABLES AS SELECT
   s.handle, t.source_schema_name, t.source_table_name, s.view_name,
   t.change_set_name, u.subscription_name
  FROM sys.cdc_subscribed_tables$ s, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ u, sys.user$ su
  WHERE s.change_table_obj#=t.obj# AND
        s.handle=u.handle AND
        u.username= su.name AND
        su.user#= USERENV('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_SUBSCRIBED_TABLES IS 'Change Data Capture subscribed tables'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.HANDLE IS 'Unique identifier of the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.SOURCE_SCHEMA_NAME IS 'Source schema name of the subscribed table'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.SOURCE_TABLE_NAME IS 'Source table name of the subscribed table'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.VIEW_NAME IS 'Subscriber view name for the subscribed table'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.CHANGE_SET_NAME IS 'Change set name for the subscribed table'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_TABLES.SUBSCRIPTION_NAME IS 'Name of the subscription'
/

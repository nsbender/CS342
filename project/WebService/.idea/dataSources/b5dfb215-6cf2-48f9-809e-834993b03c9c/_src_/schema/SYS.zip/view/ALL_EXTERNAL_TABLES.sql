CREATE VIEW ALL_EXTERNAL_TABLES AS select u.name, o.name, 'SYS', xt.type$, 'SYS', xt.default_dir,
       decode(xt.reject_limit, 2147483647, 'UNLIMITED', xt.reject_limit),
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end,
       decode(xt.property, 2, 'REFERENCED', 1, 'ALL',     'UNKNOWN')
from sys.external_tab$ xt, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.obj#   = xt.obj#
  and ( o.owner# = userenv('SCHEMAID')
        or o.obj# in
            ( select oa.obj# from sys.objauth$ oa
              where grantee# in (select kzsrorol from x$kzsro)
            )
        or    /* user has system privileges */
          exists ( select null from v$enabledprivs
                   where priv_number in (-45 /* LOCK ANY TABLE */,
                                         -47 /* SELECT ANY TABLE */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_EXTERNAL_TABLES IS 'Description of the external tables accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.OWNER IS 'Owner of the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.TABLE_NAME IS 'Name of the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.TYPE_OWNER IS 'Owner of the implementation type for the external table access driver'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.TYPE_NAME IS 'Name of the implementation type for the external table access driver'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.DEFAULT_DIRECTORY_OWNER IS 'Owner of the default directory for the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.DEFAULT_DIRECTORY_NAME IS 'Name of the default directory for the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.REJECT_LIMIT IS 'Reject limit for the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.ACCESS_TYPE IS 'Type of access parameters for the external table (CLOB/BLOB)'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.ACCESS_PARAMETERS IS 'Access parameters for the external table'
/
COMMENT ON COLUMN SYS.ALL_EXTERNAL_TABLES.PROPERTY IS 'Property of the external table'
/

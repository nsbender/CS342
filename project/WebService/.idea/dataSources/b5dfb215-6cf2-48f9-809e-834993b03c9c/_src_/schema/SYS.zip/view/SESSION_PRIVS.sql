CREATE VIEW SESSION_PRIVS AS select spm.name
from sys.v$enabledprivs ep, system_privilege_map spm
where spm.privilege = ep.priv_number
/
COMMENT ON VIEW SYS.SESSION_PRIVS IS 'Privileges which the user currently has set'
/
COMMENT ON COLUMN SYS.SESSION_PRIVS.PRIVILEGE IS 'Privilege Name'
/

CREATE VIEW ALL_PARTIAL_DROP_TABS AS select u.name, o.name
from sys.user$ u, sys.obj$ o, sys.tab$ t
where o.owner# = u.user#
  and o.obj# = t.obj#
  and bitand(t.flags,32768) = 32768
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
      )
  group by u.name, o.name
/
COMMENT ON VIEW SYS.ALL_PARTIAL_DROP_TABS IS 'All tables with patially dropped columns accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_PARTIAL_DROP_TABS.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.ALL_PARTIAL_DROP_TABS.TABLE_NAME IS 'Name of the table'
/

CREATE VIEW USER_COL_COMMENTS AS select o.name, c.name, co.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.com$ co
where o.owner# = userenv('SCHEMAID')
  and o.type# in (2, 4)
  and o.obj# = c.obj#
  and c.obj# = co.obj#(+)
  and c.intcol# = co.col#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
/
COMMENT ON VIEW SYS.USER_COL_COMMENTS IS 'Comments on columns of user''s tables and views'
/
COMMENT ON COLUMN SYS.USER_COL_COMMENTS.TABLE_NAME IS 'Object name'
/
COMMENT ON COLUMN SYS.USER_COL_COMMENTS.COLUMN_NAME IS 'Column name'
/
COMMENT ON COLUMN SYS.USER_COL_COMMENTS.COMMENTS IS 'Comment on the column'
/

CREATE VIEW LOADER_PART_INFO AS select
  o.subname                                                 as pname,
  o.name                                                    as tname,
  u.name                                                    as owner,
  tp.obj#                                                   as objectno,
  tp.bo#                                                    as baseobjectno,
  tp.ts#                                                    as tablespaceno,
  po.parttype                                               as parttype,
  row_number() over (partition by tp.bo# order by tp.part#) as partpos
from sys.obj$ o, sys.tabpart$ tp, sys.partobj$ po, user$ u
where o.obj#   = tp.obj#
and   po.obj#  = tp.bo#
and   o.owner# = u.user#
 and (o.owner# = userenv('schemaid')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK   ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
/

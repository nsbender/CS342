CREATE VIEW USER_SEQUENCES AS select o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater
from sys.seq$ s, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.obj# = s.obj#
/
COMMENT ON VIEW SYS.USER_SEQUENCES IS 'Description of the user''s own SEQUENCEs'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.SEQUENCE_NAME IS 'SEQUENCE name'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.MIN_VALUE IS 'Minimum value of the sequence'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.MAX_VALUE IS 'Maximum value of the sequence'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.INCREMENT_BY IS 'Value by which sequence is incremented'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.CYCLE_FLAG IS 'Does sequence wrap around on reaching limit?'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.ORDER_FLAG IS 'Are sequence numbers generated in order?'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.CACHE_SIZE IS 'Number of sequence numbers to cache'
/
COMMENT ON COLUMN SYS.USER_SEQUENCES.LAST_NUMBER IS 'Last sequence number written to disk'
/

CREATE VIEW USER_ASSEMBLIES AS select o.name,
       a.filespec,
       decode(a.security_level, 0, 'SAFE', 1, 'EXTERNAL_1', 2, 'EXTERNAL_2',
                                3, 'EXTERNAL_3', 4, 'UNSAFE'),
       a.identity,
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
from sys."_CURRENT_EDITION_OBJ" o, sys.assembly$ a
where o.owner# = userenv('SCHEMAID')
  and o.obj# = a.obj#
/
COMMENT ON VIEW SYS.USER_ASSEMBLIES IS 'Description of the user''s own assemblies'
/
COMMENT ON COLUMN SYS.USER_ASSEMBLIES.ASSEMBLY_NAME IS 'Name of the assembly'
/
COMMENT ON COLUMN SYS.USER_ASSEMBLIES.FILE_SPEC IS 'Operating system file specification of the assembly'
/
COMMENT ON COLUMN SYS.USER_ASSEMBLIES.SECURITY_LEVEL IS 'The maximum security level of the assembly'
/
COMMENT ON COLUMN SYS.USER_ASSEMBLIES.IDENTITY IS 'The identity of the assembly'
/
COMMENT ON COLUMN SYS.USER_ASSEMBLIES.STATUS IS 'Status of the assembly'
/

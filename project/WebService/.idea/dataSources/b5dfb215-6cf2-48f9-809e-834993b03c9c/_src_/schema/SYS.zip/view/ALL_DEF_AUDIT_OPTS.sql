CREATE VIEW ALL_DEF_AUDIT_OPTS AS select substr(t.audit$, 1, 1) || '/' || substr(t.audit$, 2, 1),
       substr(t.audit$, 3, 1) || '/' || substr(t.audit$, 4, 1),
       substr(t.audit$, 5, 1) || '/' || substr(t.audit$, 6, 1),
       substr(t.audit$, 7, 1) || '/' || substr(t.audit$, 8, 1),
       substr(t.audit$, 9, 1) || '/' || substr(t.audit$, 10, 1),
       substr(t.audit$, 11, 1) || '/' || substr(t.audit$, 12, 1),
       substr(t.audit$, 13, 1) || '/' || substr(t.audit$, 14, 1),
       substr(t.audit$, 15, 1) || '/' || substr(t.audit$, 16, 1),
       substr(t.audit$, 17, 1) || '/' || substr(t.audit$, 18, 1),
       substr(t.audit$, 19, 1) || '/' || substr(t.audit$, 20, 1),
       substr(t.audit$, 21, 1) || '/' || substr(t.audit$, 22, 1),
       '-/-',                                            /* dummy REF column */
       substr(t.audit$, 25, 1) || '/' || substr(t.audit$, 26, 1),
       substr(t.audit$, 23, 1) || '/' || substr(t.audit$, 24, 1),
       substr(t.audit$, 29, 1) || '/' || substr(t.audit$, 30, 1)
from sys.obj$ o, sys.tab$ t
where o.obj# = t.obj#
  and o.owner# = 0
  and o.name = '_default_auditing_options_'
/
COMMENT ON VIEW SYS.ALL_DEF_AUDIT_OPTS IS 'Auditing options for newly created objects'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.ALT IS 'Auditing ALTER WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.AUD IS 'Auditing AUDIT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.COM IS 'Auditing COMMENT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.DEL IS 'Auditing DELETE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.GRA IS 'Auditing GRANT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.IND IS 'Auditing INDEX WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.INS IS 'Auditing INSERT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.LOC IS 'Auditing LOCK WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.REN IS 'Auditing RENAME WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.SEL IS 'Auditing SELECT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.UPD IS 'Auditing UPDATE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.REF IS 'Dummy REF column. Maintained for backward compatibility of the view'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.EXE IS 'Auditing EXECUTE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.FBK IS 'Auditing FLASHBACK WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/
COMMENT ON COLUMN SYS.ALL_DEF_AUDIT_OPTS.REA IS 'Auditing READ WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

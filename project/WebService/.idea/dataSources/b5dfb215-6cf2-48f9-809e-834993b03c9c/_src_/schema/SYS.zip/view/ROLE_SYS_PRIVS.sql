CREATE VIEW ROLE_SYS_PRIVS AS select u.name,spm.name,decode(min(option$),1,'YES','NO')
from  sys.user$ u, sys.system_privilege_map spm, sys.sysauth$ sa
where grantee# in
   (select distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
  and u.user#=sa.grantee# and sa.privilege#=spm.privilege
group by u.name, spm.name
/
COMMENT ON VIEW SYS.ROLE_SYS_PRIVS IS 'System privileges granted to roles'
/
COMMENT ON COLUMN SYS.ROLE_SYS_PRIVS.ROLE IS 'Role name'
/
COMMENT ON COLUMN SYS.ROLE_SYS_PRIVS.PRIVILEGE IS 'System Privilege'
/
COMMENT ON COLUMN SYS.ROLE_SYS_PRIVS.ADMIN_OPTION IS 'Grant was with the ADMIN option'
/

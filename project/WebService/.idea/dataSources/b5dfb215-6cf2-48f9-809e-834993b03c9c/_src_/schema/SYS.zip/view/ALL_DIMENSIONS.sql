CREATE VIEW ALL_DIMENSIONS AS select u.name, o.name,
       decode(o.status, 5, 'Y', 'N'),
       decode(o.status, 1, 'VALID', 5, 'NEEDS_COMPILE', 'ERROR'),
       1                  /* Metadata revision number */
from sys.dim$ d, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.obj# = d.obj#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_DIMENSIONS IS 'Description of the dimension objects accessible to the DBA'
/
COMMENT ON COLUMN SYS.ALL_DIMENSIONS.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIMENSIONS.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIMENSIONS.INVALID IS 'Invalidity of the dimension, Y = INVALID, N = VALID.
 The column is deprecated, please use COMPILE_STATE instead.'
/
COMMENT ON COLUMN SYS.ALL_DIMENSIONS.COMPILE_STATE IS 'Compile status of the dimension, VALID/NEEDS_COMPILE/ERROR'
/
COMMENT ON COLUMN SYS.ALL_DIMENSIONS.REVISION IS 'Revision levle of the dimension'
/

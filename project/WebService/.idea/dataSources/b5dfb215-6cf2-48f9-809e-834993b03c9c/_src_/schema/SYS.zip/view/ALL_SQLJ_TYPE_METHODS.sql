CREATE VIEW ALL_SQLJ_TYPE_METHODS AS select u.name, o.name, m.name, m.externVarName, m.method#,
       decode(bitand(m.properties, 512), 512, 'MAP',
              decode(bitand(m.properties, 2048), 2048, 'ORDER', 'PUBLIC')),
       m.parameters#, m.results,
       decode(bitand(m.properties, 8), 8, 'NO', 'YES'),
       decode(bitand(m.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(m.properties, 131072), 131072, 'YES', 'NO'),
       decode(bitand(nvl(m.xflags,0), 1), 1, 'YES', 'NO')
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.type$ t, sys.method$ m
where o.owner# = u.user#
  and o.oid$ = m.toid
  and o.subname IS NULL -- get the latest version only
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.toid = m.toid
  and t.version# = m.version#
  and t.externtype < 5
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
/
COMMENT ON VIEW SYS.ALL_SQLJ_TYPE_METHODS IS 'Description of methods of types accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.OWNER IS 'Owner of the type'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.TYPE_NAME IS 'Name of the type'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.METHOD_NAME IS 'Name of the method'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.EXTERNAL_VAR_NAME IS 'Name of the external variable'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.METHOD_NO IS 'Method number for distinguishing overloaded method (not to be used as ID number)'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.METHOD_TYPE IS 'Type of the method'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.PARAMETERS IS 'Number of parameters to the method'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.RESULTS IS 'Number of results returned by the method'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.FINAL IS 'Is the method final ?'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.INSTANTIABLE IS 'Is the method instantiable ?'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.OVERRIDING IS 'Is the method overriding a supertype method ?'
/
COMMENT ON COLUMN SYS.ALL_SQLJ_TYPE_METHODS.INHERITED IS 'Is the method inherited from the supertype ?'
/

CREATE VIEW USER_PLSQL_OBJECT_SETTINGS AS select o.name,
decode(o.type#, 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                11, 'PACKAGE BODY', 12, 'TRIGGER',
                13, 'TYPE', 14, 'TYPE BODY', 22, 'LIBRARY', 'UNDEFINED'),
(select to_number(value) from settings$ s
  where s.obj# = o.obj# and param = 'plsql_optimize_level'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_code_type'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_debug'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_warnings'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'nls_length_semantics'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_ccflags'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plscope_settings')
from sys."_CURRENT_EDITION_OBJ" o
where o.owner# = userenv('SCHEMAID')
  and (o.type# in (7, 8, 9, 11, 12, 14, 22)
  or  (o.type# = 13 and o.subname is null))
/
COMMENT ON VIEW SYS.USER_PLSQL_OBJECT_SETTINGS IS 'Compiler settings of stored objects owned by the user'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.TYPE IS 'Type of the object: "PROCEDURE", "FUNCTION",
"PACKAGE", "PACKAGE BODY", "TRIGGER", "TYPE", "TYPE BODY" or "LIBRARY"'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSQL_OPTIMIZE_LEVEL IS 'The optimization level to use to compile the object'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSQL_CODE_TYPE IS 'The object codes are to be compiled natively or are interpreted'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSQL_DEBUG IS 'The object is to be compiled with debug information or not'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSQL_WARNINGS IS 'The compiler warning settings to use to compile the object'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.NLS_LENGTH_SEMANTICS IS 'The NLS length semantics to use to compile the object'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSQL_CCFLAGS IS 'The conditional compilation flag settings to use to compile the object'
/
COMMENT ON COLUMN SYS.USER_PLSQL_OBJECT_SETTINGS.PLSCOPE_SETTINGS IS 'Settings for using PL/Scope'
/

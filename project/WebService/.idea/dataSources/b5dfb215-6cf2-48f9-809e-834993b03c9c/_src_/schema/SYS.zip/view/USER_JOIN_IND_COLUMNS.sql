CREATE VIEW USER_JOIN_IND_COLUMNS AS select
  oi.name,
  uti.name, oti.name, ci.name,
  uto.name, oto.name, co.name
from
  sys.user$ uti, sys.user$ uto,
  sys.obj$ oi, sys.obj$ oti, sys.obj$ oto,
  sys.col$ ci, sys.col$ co,
  sys.jijoin$ ji
where ji.obj# = oi.obj#
  and ji.tab1obj# = oti.obj#
  and oti.owner# = uti.user#
  and ci.obj# = oti.obj#
  and ji.tab1col# = ci.intcol#
  and ji.tab2obj# = oto.obj#
  and oto.owner# = uto.user#
  and co.obj# = oto.obj#
  and ji.tab2col# = co.intcol#
  and oi.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_JOIN_IND_COLUMNS IS 'Join Index columns comprising the join conditions'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.INDEX_NAME IS 'Index name'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.INNER_TABLE_OWNER IS 'Table owner of inner table (table closer to the fact table)'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.INNER_TABLE_NAME IS 'Table name of inner table (table closer to the fact table)'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.INNER_TABLE_COLUMN IS 'Column name of inner table (table closer to the fact table)'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.OUTER_TABLE_OWNER IS 'Table owner of outer table (table closer to the fact table)'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.OUTER_TABLE_NAME IS 'Table name of outer table (table closer to the fact table)'
/
COMMENT ON COLUMN SYS.USER_JOIN_IND_COLUMNS.OUTER_TABLE_COLUMN IS 'Column name of outer table (table closer to the fact table)'
/

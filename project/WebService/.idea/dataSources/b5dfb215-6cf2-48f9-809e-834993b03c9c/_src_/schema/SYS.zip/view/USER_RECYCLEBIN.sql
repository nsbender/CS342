CREATE VIEW USER_RECYCLEBIN AS select o.name, r.original_name,
       decode(r.operation, 0, 'DROP', 1, 'TRUNCATE', 'UNDEFINED'),
       decode(r.type#, 1, 'TABLE', 2, 'INDEX', 3, 'INDEX',
                       4, 'NESTED TABLE', 5, 'LOB', 6, 'LOB INDEX',
                       7, 'DOMAIN INDEX', 8, 'IOT TOP INDEX',
                       9, 'IOT OVERFLOW SEGMENT', 10, 'IOT MAPPING TABLE',
                       11, 'TRIGGER', 12, 'CONSTRAINT', 13, 'Table Partition',
                       14, 'Table Composite Partition', 15, 'Index Partition',
                       16, 'Index Composite Partition', 17, 'LOB Partition',
                       18, 'LOB Composite Partition',
                       'UNDEFINED'),
       t.name,
       to_char(o.ctime, 'YYYY-MM-DD:HH24:MI:SS'),
       to_char(r.droptime, 'YYYY-MM-DD:HH24:MI:SS'),
       r.dropscn, r.partition_name,
       decode(bitand(r.flags, 4), 0, 'NO', 4, 'YES', 'NO'),
       decode(bitand(r.flags, 2), 0, 'NO', 2, 'YES', 'NO'),
       r.related, r.bo, r.purgeobj, r.space
from sys."_CURRENT_EDITION_OBJ" o, sys.recyclebin$ r, sys.ts$ t
where r.owner# = userenv('SCHEMAID')
  and o.obj# = r.obj#
  and r.ts# = t.ts#(+)
/
COMMENT ON VIEW SYS.USER_RECYCLEBIN IS 'User view of his recyclebin'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.OBJECT_NAME IS 'New name of the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.ORIGINAL_NAME IS 'Original name of the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.OPERATION IS 'Operation carried out on the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.TYPE IS 'Type of the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.TS_NAME IS 'Tablespace Name to which object belongs'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.CREATETIME IS 'Timestamp for the creating of the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.DROPTIME IS 'Timestamp for the dropping of the object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.DROPSCN IS 'SCN of the transaction which moved object to Recycle Bin'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.PARTITION_NAME IS 'Partition Name which was dropped'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.CAN_UNDROP IS 'User can undrop this object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.CAN_PURGE IS 'User can undrop this object'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.RELATED IS 'Parent objects Obj#'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.BASE_OBJECT IS 'Base objects Obj#'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.PURGE_OBJECT IS 'Obj# for object which gets purged'
/
COMMENT ON COLUMN SYS.USER_RECYCLEBIN.SPACE IS 'Number of blocks used by this object'
/

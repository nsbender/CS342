CREATE VIEW USER_CLUSTER_HASH_EXPRESSIONS AS select us.name, o.name, c.condition
from sys.cdef$ c, sys.user$ us, sys.obj$ o
where c.type#   = 8
and   c.obj#   = o.obj#
and   us.user# = o.owner#
and   us.user# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_CLUSTER_HASH_EXPRESSIONS IS 'Hash functions for the user''s hash clusters'
/
COMMENT ON COLUMN SYS.USER_CLUSTER_HASH_EXPRESSIONS.OWNER IS 'Name of owner of cluster'
/
COMMENT ON COLUMN SYS.USER_CLUSTER_HASH_EXPRESSIONS.CLUSTER_NAME IS 'Name of cluster'
/
COMMENT ON COLUMN SYS.USER_CLUSTER_HASH_EXPRESSIONS.HASH_EXPRESSION IS 'Text of hash function of cluster'
/

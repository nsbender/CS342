CREATE VIEW USER_COLL_TYPES AS select o.name, co.name, c.upper_bound,
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER')),
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#),
            decode(bitand(et.properties, 64), 64, null, eu.name)),
       nvl2(c.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o where o.obj#=c.synobj#),
            decode(et.typecode,
                   9, decode(c.charsetform, 2, 'NVARCHAR2', eo.name),
                   96, decode(c.charsetform, 2, 'NCHAR', eo.name),
                   112, decode(c.charsetform, 2, 'NCLOB', eo.name),
                   eo.name)),
       c.length, c.precision, c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES')
from sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c, sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.type$ et
where o.owner# = userenv('SCHEMAID')
  and o.oid$ = c.toid
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and c.elem_toid = eo.oid$
  and eo.owner# = eu.user#
  and c.elem_toid = et.tvoid
/
COMMENT ON VIEW SYS.USER_COLL_TYPES IS 'Description of the user''s own named collection types'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.TYPE_NAME IS 'Name of the type'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.COLL_TYPE IS 'Collection type'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.UPPER_BOUND IS 'Size of the FIXED ARRAY type or maximum size of the VARYING ARRAY type'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.ELEM_TYPE_MOD IS 'Type modifier of the element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.ELEM_TYPE_OWNER IS 'Owner of the type of the element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.ELEM_TYPE_NAME IS 'Name of the type of the element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.LENGTH IS 'Length of the CHAR element or maximum length of the VARCHAR
or VARCHAR2 element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.PRECISION IS 'Decimal precision of the NUMBER or DECIMAL element or
binary precision of the FLOAT element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.SCALE IS 'Scale of the NUMBER or DECIMAL element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.CHARACTER_SET_NAME IS 'Character set name of the element'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.ELEM_STORAGE IS 'Storage optimization specification for VARRAY of numeric elements'
/
COMMENT ON COLUMN SYS.USER_COLL_TYPES.NULLS_STORED IS 'Is null information stored with each VARRAY element?'
/

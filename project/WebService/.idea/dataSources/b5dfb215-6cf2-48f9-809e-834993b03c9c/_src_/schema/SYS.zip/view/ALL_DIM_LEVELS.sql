CREATE VIEW ALL_DIM_LEVELS AS select u.name, o.name, dl.levelname,
       temp.num_col,
       u1.name, o1.name, decode (dl.flags, 1, 'Y', 'N')
from (select dlk.dimobj#, dlk.levelid#, dlk.detailobj#,
             COUNT(*) as num_col
      from sys.dimlevelkey$ dlk
      group by dlk.dimobj#, dlk.levelid#, dlk.detailobj#) temp,
      sys.dimlevel$ dl, sys.obj$ o, sys.user$ u,
      sys.obj$ o1, sys.user$ u1
where dl.dimobj# = o.obj#   and
      o.owner# = u.user#    and
      dl.dimobj# = temp.dimobj# and
      dl.levelid# = temp.levelid# and
      temp.detailobj# = o1.obj# and
      o1.owner# = u1.user# and
      (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_DIM_LEVELS IS 'Description of dimension levels visible to DBA'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.LEVEL_NAME IS 'Name of the dimension level (unique within a dimension)'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.NUM_COLUMNS IS 'Number of columns in the level definition'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.DETAILOBJ_OWNER IS 'Owner of the detail object that the keys of this level come from'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.DETAILOBJ_NAME IS 'Name of the table that the keys of this level come from'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVELS.SKIP_WHEN_NULL IS 'Is the level declared with SKIP WHEN NULL clause? (Y/N)'
/

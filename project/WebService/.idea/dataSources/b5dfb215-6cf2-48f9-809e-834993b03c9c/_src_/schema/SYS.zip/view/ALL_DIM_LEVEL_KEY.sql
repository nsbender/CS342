CREATE VIEW ALL_DIM_LEVEL_KEY AS select u.name, o.name, dl.levelname, dlk.keypos#, c.name
from sys.dimlevelkey$ dlk, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl,
     sys.col$ c
where dlk.dimobj# = o.obj#
  and o.owner# = u.user#
  and dlk.dimobj# = dl.dimobj#
  and dlk.levelid# = dl.levelid#
  and dlk.detailobj# = c.obj#
  and dlk.col# = c.intcol#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_DIM_LEVEL_KEY IS 'Representations of columns of a dimension level'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVEL_KEY.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVEL_KEY.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVEL_KEY.LEVEL_NAME IS 'Name of the hierarchy level'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVEL_KEY.KEY_POSITION IS 'Ordinal position of the key column within the level'
/
COMMENT ON COLUMN SYS.ALL_DIM_LEVEL_KEY.COLUMN_NAME IS 'Name of the key column'
/

CREATE VIEW ALL_REWRITE_EQUIVALENCES AS select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and m.name   = o.name
  and u.name   = m.owner
  and ( o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/
COMMENT ON VIEW SYS.ALL_REWRITE_EQUIVALENCES IS 'Description of all rewrite equivalence accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_REWRITE_EQUIVALENCES.OWNER IS 'Owner of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.ALL_REWRITE_EQUIVALENCES.NAME IS 'Name of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.ALL_REWRITE_EQUIVALENCES.SOURCE_STMT IS 'Source statement of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.ALL_REWRITE_EQUIVALENCES.DESTINATION_STMT IS 'Destination of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.ALL_REWRITE_EQUIVALENCES.REWRITE_MODE IS 'Rewrite mode of the rewrite equivalence'
/

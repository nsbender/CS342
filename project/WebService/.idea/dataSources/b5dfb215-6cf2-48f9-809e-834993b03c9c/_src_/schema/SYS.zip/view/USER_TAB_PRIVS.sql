CREATE VIEW USER_TAB_PRIVS AS select ue.name, u.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.user$ ue, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and oa.col# is null
  and u.user# = o.owner#
  and oa.privilege# = tpm.privilege
  and userenv('SCHEMAID') in (oa.grantor#, oa.grantee#, o.owner#)
/
COMMENT ON VIEW SYS.USER_TAB_PRIVS IS 'Grants on objects for which the user is the owner, grantor or grantee'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.GRANTEE IS 'Name of the user to whom access was granted'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.OWNER IS 'Owner of the object'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.GRANTOR IS 'Name of the user who performed the grant'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.PRIVILEGE IS 'Table Privilege'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.GRANTABLE IS 'Privilege is grantable'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS.HIERARCHY IS 'Privilege is with hierarchy option'
/

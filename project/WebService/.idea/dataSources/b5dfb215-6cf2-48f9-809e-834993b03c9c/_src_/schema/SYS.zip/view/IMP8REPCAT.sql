CREATE VIEW IMP8REPCAT AS SELECT  name, type#
        FROM    sys.obj$
        WHERE   name IN ('DBMS_SNAPSHOT_UTL', 'DBMS_REPCAT_MIG') AND
                type# = 11 AND
                owner# = 0
/

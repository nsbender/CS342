CREATE VIEW EXU8ORDOP AS SELECT                                              /*+ no_filtering */
                MAX(level), d1.d_obj#, d1.owner#
        FROM    (
                    SELECT                                      /*+ no_merge */
                            d.d_obj#, d.p_obj#, v.owner#
                    FROM    sys.dependency$ d,
                    (select obj#, owner# from sys.obj$ where type#=33) v
                    WHERE   v.obj# = d.d_obj#) d1
        CONNECT BY PRIOR d1.d_obj# = d1.p_obj#
        GROUP BY d1.d_obj#, d1.owner#
/

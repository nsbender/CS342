CREATE VIEW USER_RESOURCE_LIMITS AS select m.name,
          decode (u.limit#, 2147483647, 'UNLIMITED',
                           0, decode (p.limit#, 2147483647, 'UNLIMITED',
                                               p.limit#),
                           u.limit#)
  from sys.profile$ u, sys.profile$ p,
       sys.resource_map m, user$ s
  where u.resource# = m.resource#
  and p.profile# = 0
  and p.resource# = u.resource#
  and u.type# = p.type#
  and p.type# = 0
  and m.type# = 0
  and s.resource$ = u.profile#
  and s.user# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_RESOURCE_LIMITS IS 'Display resource limit of the user'
/
COMMENT ON COLUMN SYS.USER_RESOURCE_LIMITS.RESOURCE_NAME IS 'Resource name'
/
COMMENT ON COLUMN SYS.USER_RESOURCE_LIMITS.LIMIT IS 'Limit placed on this resource'
/

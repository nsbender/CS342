CREATE VIEW USER_SYS_PRIVS AS select decode(sa.grantee#,1,'PUBLIC',su.name),spm.name,
       decode(min(option$),1,'YES','NO')
from  sys.system_privilege_map spm, sys.sysauth$ sa, sys.user$ su
where ((sa.grantee#=userenv('SCHEMAID') and su.user#=sa.grantee#)
       or sa.grantee#=1)
  and sa.privilege#=spm.privilege
group by decode(sa.grantee#,1,'PUBLIC',su.name),spm.name
/
COMMENT ON VIEW SYS.USER_SYS_PRIVS IS 'System privileges granted to current user'
/
COMMENT ON COLUMN SYS.USER_SYS_PRIVS.USERNAME IS 'User Name or PUBLIC'
/
COMMENT ON COLUMN SYS.USER_SYS_PRIVS.PRIVILEGE IS 'System privilege'
/
COMMENT ON COLUMN SYS.USER_SYS_PRIVS.ADMIN_OPTION IS 'Grant was with the ADMIN option'
/

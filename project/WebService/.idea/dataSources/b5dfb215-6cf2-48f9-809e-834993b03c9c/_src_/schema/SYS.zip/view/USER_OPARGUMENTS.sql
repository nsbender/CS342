CREATE VIEW USER_OPARGUMENTS AS select  c.name, b.name, a.bind#, a.position, a.type
  from  sys.oparg$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
  and   b.owner# = userenv ('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_OPARGUMENTS IS 'All operator arguments of operators defined by user'
/
COMMENT ON COLUMN SYS.USER_OPARGUMENTS.OWNER IS 'Owner of the operator'
/
COMMENT ON COLUMN SYS.USER_OPARGUMENTS.OPERATOR_NAME IS 'Name of the operator'
/
COMMENT ON COLUMN SYS.USER_OPARGUMENTS.BINDING# IS 'Binding# of the operator'
/
COMMENT ON COLUMN SYS.USER_OPARGUMENTS.POSITION IS 'Position of the operator argument'
/
COMMENT ON COLUMN SYS.USER_OPARGUMENTS.ARGUMENT_TYPE IS 'Datatype of the operator argument'
/

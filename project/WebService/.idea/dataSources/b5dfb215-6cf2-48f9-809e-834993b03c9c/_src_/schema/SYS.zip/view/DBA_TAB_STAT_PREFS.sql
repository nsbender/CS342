CREATE VIEW DBA_TAB_STAT_PREFS AS select u.name, o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o, user$ u
where p.obj#=o.obj#
  and u.user#=o.owner#
  and o.type#=2
/
COMMENT ON VIEW SYS.DBA_TAB_STAT_PREFS IS 'Statistics preferences for tables'
/
COMMENT ON COLUMN SYS.DBA_TAB_STAT_PREFS.OWNER IS 'Name of the owner'
/
COMMENT ON COLUMN SYS.DBA_TAB_STAT_PREFS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.DBA_TAB_STAT_PREFS.PREFERENCE_NAME IS 'Preference name'
/
COMMENT ON COLUMN SYS.DBA_TAB_STAT_PREFS.PREFERENCE_VALUE IS 'Preference value'
/

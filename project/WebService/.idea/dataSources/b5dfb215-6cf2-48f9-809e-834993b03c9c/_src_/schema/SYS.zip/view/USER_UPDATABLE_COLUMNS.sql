CREATE VIEW USER_UPDATABLE_COLUMNS AS select u.name, o.name, c.name,
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,8192), 8192, 'YES', 'NO'),
              decode(bitand(c.property,4096),4096,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,4096), 4096, 'YES', 'NO'),
              decode(bitand(c.property,2048),2048,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,16384), 16384, 'YES', 'NO'),
              decode(bitand(c.property,8192),8192,'NO','YES'))
from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.col$ c, sys.view$ v
where u.user# = o.owner#
  and c.obj#  = o.obj#
  and c.obj#  = v.obj#(+)
  and u.user# = userenv('SCHEMAID')
  and bitand(c.property, 32) = 0 /* not hidden column */
/
COMMENT ON VIEW SYS.USER_UPDATABLE_COLUMNS IS 'Description of updatable columns'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.OWNER IS 'Table owner'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.TABLE_NAME IS 'Table name'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.COLUMN_NAME IS 'Column name'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.UPDATABLE IS 'Is the column updatable?'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.INSERTABLE IS 'Is the column insertable?'
/
COMMENT ON COLUMN SYS.USER_UPDATABLE_COLUMNS.DELETABLE IS 'Is the column deletable?'
/

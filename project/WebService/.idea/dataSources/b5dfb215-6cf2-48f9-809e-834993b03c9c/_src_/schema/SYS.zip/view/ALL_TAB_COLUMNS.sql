CREATE VIEW ALL_TAB_COLUMNS AS select OWNER, TABLE_NAME,
       COLUMN_NAME, DATA_TYPE, DATA_TYPE_MOD, DATA_TYPE_OWNER,
       DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, COLUMN_ID,
       DEFAULT_LENGTH, DATA_DEFAULT, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE,
       DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED, SAMPLE_SIZE,
       CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH,
       GLOBAL_STATS, USER_STATS, AVG_COL_LEN, CHAR_LENGTH, CHAR_USED,
       V80_FMT_IMAGE, DATA_UPGRADED, HISTOGRAM
  from ALL_TAB_COLS
 where HIDDEN_COLUMN = 'NO'
/
COMMENT ON VIEW SYS.ALL_TAB_COLUMNS IS 'Columns of user''s tables, views and clusters'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.TABLE_NAME IS 'Table, view or cluster name'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.COLUMN_NAME IS 'Column name'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_TYPE IS 'Datatype of the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_TYPE_MOD IS 'Datatype modifier of the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_TYPE_OWNER IS 'Owner of the datatype of the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_LENGTH IS 'Length of the column in bytes'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_PRECISION IS 'Length: decimal digits (NUMBER) or binary digits (FLOAT)'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_SCALE IS 'Digits to right of decimal point in a number'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.NULLABLE IS 'Does column allow NULL values?'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.COLUMN_ID IS 'Sequence number of the column as created'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DEFAULT_LENGTH IS 'Length of default value for the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_DEFAULT IS 'Default value for the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.NUM_DISTINCT IS 'The number of distinct values in the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.LOW_VALUE IS 'The low value in the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.HIGH_VALUE IS 'The high value in the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DENSITY IS 'The density of the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.NUM_NULLS IS 'The number of nulls in the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.NUM_BUCKETS IS 'The number of buckets in histogram for the column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.LAST_ANALYZED IS 'The date of the most recent time this column was analyzed'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.SAMPLE_SIZE IS 'The sample size used in analyzing this column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.CHARACTER_SET_NAME IS 'Character set name'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.CHAR_COL_DECL_LENGTH IS 'Declaration length of character type column'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.GLOBAL_STATS IS 'Are the statistics calculated without merging underlying partitions?'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.USER_STATS IS 'Were the statistics entered directly by the user?'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.AVG_COL_LEN IS 'The average length of the column in bytes'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.CHAR_LENGTH IS 'The maximum length of the column in characters'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.CHAR_USED IS 'C if maximum length is specified in characters, B if in bytes'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.V80_FMT_IMAGE IS 'Is column data in 8.0 image format?'
/
COMMENT ON COLUMN SYS.ALL_TAB_COLUMNS.DATA_UPGRADED IS 'Has column data been upgraded to the latest type version format?'
/

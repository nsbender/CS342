CREATE VIEW ALL_MINING_MODELS AS select u.name, o.name,
       cast(decode(func, /* Mining Function */
              1, 'CLASSIFICATION',
              2, 'REGRESSION',
              3, 'CLUSTERING',
              4, 'FEATURE_EXTRACTION',
              5, 'ASSOCIATION_RULES',
              6, 'ATTRIBUTE_IMPORTANCE',
                 'UNDEFINED') as varchar2(30)),
       cast(decode(alg, /* Mining Algorithm */
              1, 'NAIVE_BAYES',
              2, 'ADAPTIVE_BAYES_NETWORK',
              3, 'DECISION_TREE',
              4, 'SUPPORT_VECTOR_MACHINES',
              5, 'KMEANS',
              6, 'O_CLUSTER',
              7, 'NONNEGATIVE_MATRIX_FACTOR',
              8, 'GENERALIZED_LINEAR_MODEL',
              9, 'APRIORI_ASSOCIATION_RULES',
             10, 'MINIMUM_DESCRIPTION_LENGTH',
                 'UNDEFINED') as varchar2(30)),
       o.ctime, bdur, msize, c.comment$
from sys.model$ m, sys.obj$ o, sys.user$ u, sys.com$ c
where o.obj#=m.obj#
  and o.obj#=c.obj#(+)
  and o.type#=82
  and o.owner#=u.user#
  and (o.owner#=userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-292 /* DROP ANY MINING MODEL */,
                                        -293 /* SELECT ANY MINING MODEL */,
                                        -294 /* ALTER ANY MINING MODEL */)
                  )
      )
/
COMMENT ON VIEW SYS.ALL_MINING_MODELS IS 'Description of the models accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.MODEL_NAME IS 'Name of the model'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.MINING_FUNCTION IS 'Mining function of the model'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.ALGORITHM IS 'Algorithm of the model'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.CREATION_DATE IS 'Creation date of the model'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.BUILD_DURATION IS 'Model build time (in seconds)'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.MODEL_SIZE IS 'Model size (in Mb)'
/
COMMENT ON COLUMN SYS.ALL_MINING_MODELS.COMMENTS IS 'Model comments'
/

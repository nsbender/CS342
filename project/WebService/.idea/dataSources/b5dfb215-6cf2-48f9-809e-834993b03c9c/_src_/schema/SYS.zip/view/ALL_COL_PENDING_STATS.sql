CREATE VIEW ALL_COL_PENDING_STATS AS select u.name, o.name, null, null, c.name, h.distcnt,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.lowval
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.hival
              else null
         end,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.user$ u, sys.obj$ o, sys.col$ c,
         sys.wri$_optstat_histhead_history h
  where  h.obj# = c.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.owner# = u.user#
    and  o.type# = 2
    and  h.savtime > systimestamp
    and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
        )
  union all
  -- partitions
  select u.name, o.name, o.subname, null, c.name, h.distcnt,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.lowval
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.hival
         else null
         end,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabpart$ t,
         sys.wri$_optstat_histhead_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
        )
  union all
  select u.name, o.name, o.subname, null, c.name, h.distcnt,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.lowval
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
            then h.hival
            else null
         end,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabcompart$ t,
         sys.wri$_optstat_histhead_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
        )
  union all
  -- sub partitions
  select u.name, op.name, op.subname, os.subname, c.name, h.distcnt,
         case when SYS_OP_DV_CHECK(op.name, op.owner#) = 1
              then h.lowval
              else null
         end,
         case when SYS_OP_DV_CHECK(op.name, op.owner#) = 1
            then h.hival
            else null
         end,
         h.density, h.null_cnt, h.avgcln, h.sample_size,
         h.timestamp#
  from  sys.obj$ os, sys.tabsubpart$ tsp, sys.tabcompart$ tcp,
        sys.user$ u, sys.col$ c, sys.obj$ op,
        sys.wri$_optstat_histhead_history h
  where os.obj# = tsp.obj#
    and os.owner# = u.user#
    and h.obj#  = tsp.obj#
    and h.intcol#= c.intcol#
    and tsp.pobj#= tcp.obj#
    and tcp.bo#  = c.obj#
    and tcp.obj# = op.obj#
    and os.type# = 34
    and h.savtime > systimestamp
    and (os.owner# = userenv('SCHEMAID')
        or os.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
        )
/
COMMENT ON VIEW SYS.ALL_COL_PENDING_STATS IS 'Pending statistics of tables, partitions, and subpartitions'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.OWNER IS 'Table owner name'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.TABLE_NAME IS 'Table name'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.PARTITION_NAME IS 'Partition name'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.SUBPARTITION_NAME IS 'Subpartition name'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.COLUMN_NAME IS 'Column name'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.NUM_DISTINCT IS 'The number of distinct values in the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.LOW_VALUE IS 'The low value in the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.HIGH_VALUE IS 'The high value in the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.DENSITY IS 'The density of the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.NUM_NULLS IS 'The number rows with value in the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.AVG_COL_LEN IS 'The average length of the column in bytes'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.SAMPLE_SIZE IS 'The sample size used in analyzing this column'
/
COMMENT ON COLUMN SYS.ALL_COL_PENDING_STATS.LAST_ANALYZED IS 'The date of the most recent time this column was analyzed'
/

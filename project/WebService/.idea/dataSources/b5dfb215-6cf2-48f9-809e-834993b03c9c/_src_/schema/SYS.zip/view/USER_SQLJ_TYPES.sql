CREATE VIEW USER_SQLJ_TYPES AS select o.name, t.toid, t.externname,
       decode(t.externtype, 1, 'SQLData',
                            2, 'CustomDatum',
                            3, 'Serializable',
                            4, 'Serializable Internal',
                            5, 'ORAData',
                            'unknown'),
       decode(t.typecode, 108, 'OBJECT',
                          122, 'COLLECTION',
                          o.name),
       t.attributes, t.methods,
       decode(bitand(t.properties, 16), 16, 'YES', 0, 'NO'),
       decode(bitand(t.properties, 256), 256, 'YES', 0, 'NO'),
       decode(bitand(t.properties, 8), 8, 'NO', 'YES'),
       decode(bitand(t.properties, 65536), 65536, 'NO', 'YES'),
       su.name, so.name, t.local_attrs, t.local_methods
from sys.type$ t, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" so,
     sys.user$ su
where o.owner# = userenv('SCHEMAID')
  and o.oid$ = t.tvoid
  and o.subname IS NULL -- only latest version
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.supertoid = so.oid$ (+) and so.owner# = su.user# (+)
  and t.externtype < 5
/
COMMENT ON VIEW SYS.USER_SQLJ_TYPES IS 'Description of the user''s own types'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.TYPE_NAME IS 'Name of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.TYPE_OID IS 'Object identifier (OID) of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.EXTERNAL_NAME IS 'External class name of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.USING IS 'Representation of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.TYPECODE IS 'Typecode of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.ATTRIBUTES IS 'Number of attributes (if any) in the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.METHODS IS 'Number of methods (if any) in the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.PREDEFINED IS 'Is the type a predefined type?'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.INCOMPLETE IS 'Is the type an incomplete type?'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.FINAL IS 'Is the type a final type?'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.INSTANTIABLE IS 'Is the type an instantiable type?'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.SUPERTYPE_OWNER IS 'Owner of the supertype (null if type is not a subtype)'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.SUPERTYPE_NAME IS 'Name of the supertype (null if type is not a subtype)'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.LOCAL_ATTRIBUTES IS 'Number of local (not inherited) attributes (if any) in the subtype'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPES.LOCAL_METHODS IS 'Number of local (not inherited) methods (if any) in the subtype'
/

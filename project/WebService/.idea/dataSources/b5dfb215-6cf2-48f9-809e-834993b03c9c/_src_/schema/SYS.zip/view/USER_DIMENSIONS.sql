CREATE VIEW USER_DIMENSIONS AS select u.name, o.name,
       decode(o.status, 5, 'Y', 'N'),
       decode(o.status, 1, 'VALID', 5, 'NEEDS_COMPILE', 'ERROR'),
       1                  /* Metadata revision number */
from sys.dim$ d, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.obj# = d.obj#
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_DIMENSIONS IS 'Description of the dimension objects accessible to the DBA'
/
COMMENT ON COLUMN SYS.USER_DIMENSIONS.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIMENSIONS.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIMENSIONS.INVALID IS 'Invalidity of the dimension, Y = INVALID, N = VALID.
 The column is deprecated, please use COMPILE_STATE instead.'
/
COMMENT ON COLUMN SYS.USER_DIMENSIONS.COMPILE_STATE IS 'Compile status of the dimension, VALID/NEEDS_COMPILE/ERROR'
/
COMMENT ON COLUMN SYS.USER_DIMENSIONS.REVISION IS 'Revision levle of the dimension'
/

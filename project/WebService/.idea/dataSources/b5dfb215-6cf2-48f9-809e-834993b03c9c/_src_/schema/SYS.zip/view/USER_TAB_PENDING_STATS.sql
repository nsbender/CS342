CREATE VIEW USER_TAB_PENDING_STATS AS select o.name, null, null, h.rowcnt, h.blkcnt, h.avgrln,
         h.samplesize, h.analyzetime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 2
         and o.owner# = userenv('SCHEMAID')
         and h.savtime > systimestamp
  union all
  -- partitions
  select o.name, o.subname, null, h.rowcnt, h.blkcnt,
         h.avgrln, h.samplesize, h.analyzetime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 19
         and o.owner# = userenv('SCHEMAID')
         and h.savtime > systimestamp
  union all
  -- sub partitions
  select osp.name, ocp.subname, osp.subname, h.rowcnt,
         h.blkcnt, h.avgrln, h.samplesize, h.analyzetime
  from  sys.obj$ osp, sys.obj$ ocp,  sys.tabsubpart$ tsp,
        sys.wri$_optstat_tab_history h
  where h.obj# = osp.obj# and osp.type# = 34 and osp.obj# = tsp.obj#
        and tsp.pobj# = ocp.obj#
        and osp.owner# = userenv('SCHEMAID')
        and h.savtime > systimestamp
/
COMMENT ON VIEW SYS.USER_TAB_PENDING_STATS IS 'History of table statistics modifications'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.PARTITION_NAME IS 'Name of the partition'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.SUBPARTITION_NAME IS 'Name of the subpartition'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.NUM_ROWS IS 'Number of rows'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.BLOCKS IS 'Number of blocks'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.AVG_ROW_LEN IS 'Average row length'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.SAMPLE_SIZE IS 'Sample size'
/
COMMENT ON COLUMN SYS.USER_TAB_PENDING_STATS.LAST_ANALYZED IS 'Time of last analyze'
/

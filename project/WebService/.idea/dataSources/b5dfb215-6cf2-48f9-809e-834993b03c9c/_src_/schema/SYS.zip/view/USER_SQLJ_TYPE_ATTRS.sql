CREATE VIEW USER_SQLJ_TYPE_ATTRS AS select o.name, a.name, a.externname,
       decode(bitand(a.properties, 32768), 32768, 'REF',
              decode(bitand(a.properties, 16384), 16384, 'POINTER')),
       decode(bitand(at.properties, 64), 64, null, au.name),
       decode(at.typecode,
              9, decode(a.charsetform, 2, 'NVARCHAR2', ao.name),
              96, decode(a.charsetform, 2, 'NCHAR', ao.name),
              112, decode(a.charsetform, 2, 'NCLOB', ao.name),
              ao.name),
       a.length, a.precision#, a.scale,
       decode(a.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(a.charsetid),
                             4, 'ARG:'||a.charsetid),
a.attribute#, decode(bitand(nvl(a.xflags,0), 1), 1, 'YES', 'NO')
from sys."_CURRENT_EDITION_OBJ" o, sys.type$ t, sys.attribute$ a,
     sys."_CURRENT_EDITION_OBJ" ao, sys.user$ au, sys.type$ at
where o.owner# = userenv('SCHEMAID')
  and o.oid$ = t.toid
  and o.subname IS NULL -- only the latest version
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.toid = a.toid
  and t.version# = a.version#
  and a.attr_toid = ao.oid$
  and ao.owner# = au.user#
  and a.attr_toid = at.tvoid
  and a.attr_version# = at.version#
  and t.externtype < 5
/
COMMENT ON VIEW SYS.USER_SQLJ_TYPE_ATTRS IS 'Description of attributes of the user''s own types'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.TYPE_NAME IS 'Name of the type'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.ATTR_NAME IS 'Name of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.EXTERNAL_ATTR_NAME IS 'External name of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.ATTR_TYPE_MOD IS 'Type modifier of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.ATTR_TYPE_OWNER IS 'Owner of the type of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.ATTR_TYPE_NAME IS 'Name of the type of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.LENGTH IS 'Length of the CHAR attribute or maximum length of the VARCHAR
or VARCHAR2 attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.PRECISION IS 'Decimal precision of the NUMBER or DECIMAL attribute or
binary precision of the FLOAT attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.SCALE IS 'Scale of the NUMBER or DECIMAL attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.CHARACTER_SET_NAME IS 'Character set name of the attribute'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.ATTR_NO IS 'Syntactical order number or position of the attribute as specified in the
type specification or CREATE TYPE statement (not to be used as ID number)'
/
COMMENT ON COLUMN SYS.USER_SQLJ_TYPE_ATTRS.INHERITED IS 'Is the attribute inherited from the supertype ?'
/

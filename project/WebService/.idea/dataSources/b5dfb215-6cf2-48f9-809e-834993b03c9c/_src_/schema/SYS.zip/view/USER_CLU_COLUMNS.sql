CREATE VIEW USER_CLU_COLUMNS AS select oc.name, cc.name, ot.name,
       decode(bitand(tc.property, 1), 1, ac.name, tc.name)
from sys.obj$ oc, sys.col$ cc, sys.obj$ ot, sys.col$ tc, sys.tab$ t,
     sys.attrcol$ ac
where oc.obj#    = cc.obj#
  and t.bobj#    = oc.obj#
  and t.obj#     = tc.obj#
  and tc.segcol# = cc.segcol#
  and t.obj#     = ot.obj#
  and oc.type#   = 3
  and oc.owner#  = userenv('SCHEMAID')
  and tc.obj#    = ac.obj#(+)
  and tc.intcol# = ac.intcol#(+)
/
COMMENT ON VIEW SYS.USER_CLU_COLUMNS IS 'Mapping of table columns to cluster columns'
/
COMMENT ON COLUMN SYS.USER_CLU_COLUMNS.CLUSTER_NAME IS 'Cluster name'
/
COMMENT ON COLUMN SYS.USER_CLU_COLUMNS.CLU_COLUMN_NAME IS 'Key column in the cluster'
/
COMMENT ON COLUMN SYS.USER_CLU_COLUMNS.TABLE_NAME IS 'Clustered table name'
/
COMMENT ON COLUMN SYS.USER_CLU_COLUMNS.TAB_COLUMN_NAME IS 'Key column or attribute of object column in the table'
/

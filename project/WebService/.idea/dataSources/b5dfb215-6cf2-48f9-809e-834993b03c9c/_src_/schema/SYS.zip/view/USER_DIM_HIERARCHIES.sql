CREATE VIEW USER_DIM_HIERARCHIES AS select u.name, o.name, h.hiername
from sys.hier$ h, sys.obj$ o, sys.user$ u
where h.dimobj# = o.obj#
  and o.owner# = u.user#
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_DIM_HIERARCHIES IS 'Representation of a dimension hierarchy'
/
COMMENT ON COLUMN SYS.USER_DIM_HIERARCHIES.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_HIERARCHIES.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_HIERARCHIES.HIERARCHY_NAME IS 'Name of the hierarchy'
/

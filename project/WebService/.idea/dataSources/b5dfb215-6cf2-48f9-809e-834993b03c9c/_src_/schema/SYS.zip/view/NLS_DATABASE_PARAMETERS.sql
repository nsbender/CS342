CREATE VIEW NLS_DATABASE_PARAMETERS AS select name,
       substr(value$, 1, 40)
from props$
where name like 'NLS%'
/
COMMENT ON VIEW SYS.NLS_DATABASE_PARAMETERS IS 'Permanent NLS parameters of the database'
/
COMMENT ON COLUMN SYS.NLS_DATABASE_PARAMETERS.PARAMETER IS 'Parameter name'
/
COMMENT ON COLUMN SYS.NLS_DATABASE_PARAMETERS.VALUE IS 'Parameter value'
/

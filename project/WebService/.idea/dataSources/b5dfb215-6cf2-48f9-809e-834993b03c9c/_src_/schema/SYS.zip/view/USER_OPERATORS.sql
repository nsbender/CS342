CREATE VIEW USER_OPERATORS AS select c.name, b.name, a.numbind from
  sys.operator$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user# and
  b.owner# = userenv ('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_OPERATORS IS 'All user operators'
/
COMMENT ON COLUMN SYS.USER_OPERATORS.OWNER IS 'Owner of the operator'
/
COMMENT ON COLUMN SYS.USER_OPERATORS.OPERATOR_NAME IS 'Name of the operator'
/
COMMENT ON COLUMN SYS.USER_OPERATORS.NUMBER_OF_BINDS IS 'Number of bindings associated with the operator'
/

CREATE VIEW USER_ROLE_PRIVS AS select /*+ ordered */ decode(sa.grantee#, 1, 'PUBLIC', u1.name), u2.name,
       decode(min(option$), 1, 'YES', 'NO'),
       decode(min(u1.defrole), 0, 'NO', 1, decode(min(u2.password),null,'YES','NO'),
              2, decode(min(ud.role#),null,'NO','YES'),
              3, decode(min(ud.role#),null,'YES','NO'), 'NO'), 'NO'
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee# in (userenv('SCHEMAID'),1) and sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union
select su.name,u.name,decode(kzdosadm,'A','YES','NO'),
       decode(kzdosdef,'Y','YES','NO'), 'YES'
 from sys.user$ u,x$kzdos, sys.user$ su
where u.user#=x$kzdos.kzdosrol and
      su.user#=userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_ROLE_PRIVS IS 'Roles granted to current user'
/
COMMENT ON COLUMN SYS.USER_ROLE_PRIVS.USERNAME IS 'User Name or PUBLIC'
/
COMMENT ON COLUMN SYS.USER_ROLE_PRIVS.GRANTED_ROLE IS 'Granted role name'
/
COMMENT ON COLUMN SYS.USER_ROLE_PRIVS.ADMIN_OPTION IS 'Grant was with the ADMIN option'
/
COMMENT ON COLUMN SYS.USER_ROLE_PRIVS.DEFAULT_ROLE IS 'Role is designated as a DEFAULT ROLE for the user'
/
COMMENT ON COLUMN SYS.USER_ROLE_PRIVS.OS_GRANTED IS 'Role is granted via the operating system (using OS_ROLES = TRUE)'
/

CREATE VIEW USER_PENDING_CONV_TABLES AS select o.name
from sys.obj$ o
  where o.type# = 2 and o.status = 5
  and bitand(o.flags, 4096) = 4096  /* type evolved flg */
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_PENDING_CONV_TABLES IS 'All user''s tables which are not upgraded to the latest type version'
/
COMMENT ON COLUMN SYS.USER_PENDING_CONV_TABLES.TABLE_NAME IS 'Name of the table'
/

CREATE VIEW USER_USERS AS select u.name, u.user#,
       m.status,
       decode(u.astatus, 4, u.ltime,
                         5, u.ltime,
                         6, u.ltime,
                         8, u.ltime,
                         9, u.ltime,
                         10, u.ltime, to_date(NULL)),
       decode(u.astatus,
              1, u.exptime,
              2, u.exptime,
              5, u.exptime,
              6, u.exptime,
              9, u.exptime,
              10, u.exptime,
              decode(u.ptime, '', to_date(NULL),
                decode(p.limit#, 2147483647, to_date(NULL),
                 decode(p.limit#, 0,
                   decode(dp.limit#, 2147483647, to_date(NULL), u.ptime +
                     dp.limit#/86400),
                   u.ptime + p.limit#/86400)))),
       dts.name, tts.name, u.ctime,
       nvl(cgm.consumer_group, 'DEFAULT_CONSUMER_GROUP'),
       u.ext_username
from sys.user$ u left outer join sys.resource_group_mapping$ cgm
     on (cgm.attribute = 'ORACLE_USER' and cgm.status = 'ACTIVE' and
         cgm.value = u.name),
     sys.ts$ dts, sys.ts$ tts, sys.user_astatus_map m,
     profile$ p, profile$ dp
where u.datats# = dts.ts#
  and u.tempts# = tts.ts#
  and u.astatus = m.status#
  and u.type# = 1
  and u.user# = userenv('SCHEMAID')
  and u.resource$ = p.profile#
  and dp.profile# = 0
  and dp.type# = 1
  and dp.resource# = 1
  and p.type# = 1
  and p.resource# = 1
/
COMMENT ON VIEW SYS.USER_USERS IS 'Information about the current user'
/
COMMENT ON COLUMN SYS.USER_USERS.USERNAME IS 'Name of the user'
/
COMMENT ON COLUMN SYS.USER_USERS.USER_ID IS 'ID number of the user'
/
COMMENT ON COLUMN SYS.USER_USERS.DEFAULT_TABLESPACE IS 'Default tablespace for data'
/
COMMENT ON COLUMN SYS.USER_USERS.TEMPORARY_TABLESPACE IS 'Default tablespace for temporary tables'
/
COMMENT ON COLUMN SYS.USER_USERS.CREATED IS 'User creation date'
/
COMMENT ON COLUMN SYS.USER_USERS.INITIAL_RSRC_CONSUMER_GROUP IS 'User''s initial consumer group'
/
COMMENT ON COLUMN SYS.USER_USERS.EXTERNAL_NAME IS 'User external name'
/

CREATE VIEW USER_TAB_COMMENTS AS select o.name,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 'UNDEFINED'),
       c.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.com$ c
where o.owner# = userenv('SCHEMAID')
  and bitand(o.flags,128) = 0
  and (o.type# in (4)                                                /* view */
       or
       (o.type# = 2                                                /* tables */
        AND         /* excluding iot-overflow, nested or mv container tables */
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192 OR
                            bitand(t.property, 67108864) = 67108864))))
  and o.obj# = c.obj#(+)
  and c.col#(+) is null
/
COMMENT ON VIEW SYS.USER_TAB_COMMENTS IS 'Comments on the tables and views owned by the user'
/
COMMENT ON COLUMN SYS.USER_TAB_COMMENTS.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.USER_TAB_COMMENTS.TABLE_TYPE IS 'Type of the object:  "TABLE" or "VIEW"'
/
COMMENT ON COLUMN SYS.USER_TAB_COMMENTS.COMMENTS IS 'Comment on the object'
/

CREATE VIEW GV_$TIMEZONE_NAMES AS select "TZNAME","TZABBREV" from gv$timezone_names
/

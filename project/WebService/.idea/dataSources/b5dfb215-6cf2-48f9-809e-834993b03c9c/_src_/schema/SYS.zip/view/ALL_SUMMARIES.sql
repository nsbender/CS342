CREATE VIEW ALL_SUMMARIES AS select u.name, o.name, u.name, s.containernam,
       s.lastrefreshscn, s.lastrefreshdate,
       decode (s.refreshmode, 0, 'NONE', 1, 'ANY', 2, 'INCREMENTAL', 3,'FULL'),
       decode(bitand(s.pflags, 25165824), 25165824, 'N', 'Y'),
       s.fullrefreshtim, s.increfreshtim,
       decode(bitand(s.pflags, 48), 0, 'N', 'Y'),
       decode(bitand(s.mflags, 64), 0, 'N', 'Y'), /* QSMQSUM_UNUSABLE */
       decode(bitand(s.pflags, 1294319), 0, 'Y', 'N'),
       decode(bitand((select n.flag2 from sys.snap$ n
                      where n.vname=s.containernam and n.sowner=u.name), 67108864),
                     67108864,  /* primary CUBE mv? */
                     decode(bitand((select n2.flag from sys.snap$ n2
                            where n2.parent_sowner=u.name and n2.parent_vname=s.containernam), 256),
                            256, 'N', 'Y'), /* Its child mv's properties determin INC_REFRESHABLE */
                     decode(bitand(s.pflags, 236879743), 0, 'Y', 'N')),
       decode(bitand(s.mflags, 1), 0, 'N', 'Y'), /* QSMQSUM_KNOWNSTL */
       s.sumtextlen,s.sumtext
from sys.user$ u, sys.sum$ s, sys.obj$ o
where o.owner# = u.user#
  and o.obj# = s.obj#
  and bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_SUMMARIES IS 'Description of the summaries accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.OWNER IS 'Owner of the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.SUMMARY_NAME IS 'Name of the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.CONTAINER_OWNER IS 'Owner of the container table'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.CONTAINER_NAME IS 'Name of the container table for this summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.LAST_REFRESH_SCN IS 'The SCN of the last transaction to refresh the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.LAST_REFRESH_DATE IS 'The date of the last refresh of the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.REFRESH_METHOD IS 'User declared method of refresh for the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.SUMMARY IS 'Indicates the presence of either aggregation or a GROUP BY'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.FULLREFRESHTIM IS 'The time that it took to fully refresh the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.INCREFRESHTIM IS 'The time that it took to incrementally refresh the summary'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.CONTAINS_VIEWS IS 'This summary contains views in the FROM clause'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.UNUSABLE IS 'This summary is unusable, the build was deferred'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.RESTRICTED_SYNTAX IS 'This summary contains restrictive syntax'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.INC_REFRESHABLE IS 'This summary is not restricted from being incrementally refreshed'
/
COMMENT ON COLUMN SYS.ALL_SUMMARIES.KNOWN_STALE IS 'This summary is directly stale'
/

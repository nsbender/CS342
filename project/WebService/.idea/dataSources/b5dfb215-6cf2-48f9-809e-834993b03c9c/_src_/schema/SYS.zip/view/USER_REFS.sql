CREATE VIEW USER_REFS AS select distinct o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name),
       decode(bitand(rc.reftyp, 2), 2, 'YES', 'NO'),
       decode(bitand(rc.reftyp, 1), 1, 'YES', 'NO'),
       su.name, so.name,
       case
         when bitand(reftyp,4) = 4 then 'USER-DEFINED'
         when bitand(reftyp, 8) = 8 then 'SYSTEM GENERATED AND USER-DEFINED'
         else 'SYSTEM GENERATED'
       end
from sys.obj$ o, sys.col$ c, sys.refcon$ rc, sys.obj$ so, sys.user$ su,
     sys.attrcol$ ac
where o.owner# = userenv('SCHEMAID')
  and o.obj# = c.obj#
  and c.obj# = rc.obj#
  and c.col# = rc.col#
  and c.intcol# = rc.intcol#
  and rc.stabid = so.oid$(+)
  and so.owner# = su.user#(+)
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
/
COMMENT ON VIEW SYS.USER_REFS IS 'Description of the user''s own REF columns contained in the user''s own tables'
/
COMMENT ON COLUMN SYS.USER_REFS.TABLE_NAME IS 'Name of the table containing the REF column'
/
COMMENT ON COLUMN SYS.USER_REFS.COLUMN_NAME IS 'Column name or attribute of object column'
/
COMMENT ON COLUMN SYS.USER_REFS.WITH_ROWID IS 'Is the REF value stored with the rowid?'
/
COMMENT ON COLUMN SYS.USER_REFS.IS_SCOPED IS 'Is the REF column scoped?'
/
COMMENT ON COLUMN SYS.USER_REFS.SCOPE_TABLE_OWNER IS 'Owner of the scope table, if it exists'
/
COMMENT ON COLUMN SYS.USER_REFS.SCOPE_TABLE_NAME IS 'Name of the scope table, if it exists'
/
COMMENT ON COLUMN SYS.USER_REFS.OBJECT_ID_TYPE IS 'If ref contains user-defined OID, then USER-DEFINED, else if it contains system generated OID, then SYSTEM GENERATED'
/

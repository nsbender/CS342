CREATE VIEW ALL_SUMDELTA AS select s.TABLEOBJ#, s.PARTITIONOBJ#, s.DMLOPERATION, s.SCN,
          s.TIMESTAMP, s.LOWROWID, s.HIGHROWID, s.SEQUENCE, s.XID
from  sys.obj$ o, sys.user$ u, sys.sumdelta$ s
where o.type# = 2
  and o.owner# = u.user#
  and s.tableobj# = o.obj#
  and (o.owner# = userenv('SCHEMAID')
    or o.obj# in
      (select oa.obj#
         from sys.objauth$ oa
         where grantee# in ( select kzsrorol from x$kzsro)
      )
    or /* user has system privileges */
      exists (select null from v$enabledprivs
        where priv_number in (-45 /* LOCK ANY TABLE */,
                              -47 /* SELECT ANY TABLE */,
                              -48 /* INSERT ANY TABLE */,
                              -49 /* UPDATE ANY TABLE */,
                              -50 /* DELETE ANY TABLE */)
              )
      )
/
COMMENT ON VIEW SYS.ALL_SUMDELTA IS 'Direct path load entries accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.TABLEOBJ# IS 'Object number of the table'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.PARTITIONOBJ# IS 'Object number of table partitions (if the table is partitioned)'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.DMLOPERATION IS 'Type of DML operation applied to the table'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.SCN IS 'SCN when the bulk DML occurred'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.TIMESTAMP IS 'Timestamp of log entry'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.LOWROWID IS 'The start ROWID in the loaded rowid range'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.HIGHROWID IS 'The end ROWID in the loaded rowid range'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.SEQUENCE IS 'The sequence# of the direct load'
/
COMMENT ON COLUMN SYS.ALL_SUMDELTA.XID IS 'The transaction ID of the direct load'
/

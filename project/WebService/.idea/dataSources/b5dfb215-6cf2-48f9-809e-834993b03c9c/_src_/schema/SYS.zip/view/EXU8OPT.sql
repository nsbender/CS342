CREATE VIEW EXU8OPT AS SELECT  parameter, DECODE(value, 'TRUE', 1, 'FALSE', 0, 2)
        FROM    sys.v$option
/

CREATE VIEW ALL_COL_PRIVS_MADE AS select ue.name, u.name, o.name, c.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.user$ ue, sys.col$ c, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and oa.obj# = c.obj#
  and oa.col# = c.col#
  and bitand(c.property, 32) = 0 /* not hidden column */
  and oa.col# is not null
  and oa.privilege# = tpm.privilege
  and userenv('SCHEMAID') in (o.owner#, oa.grantor#)
/
COMMENT ON VIEW SYS.ALL_COL_PRIVS_MADE IS 'Grants on columns for which the user is owner or grantor'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.GRANTEE IS 'Name of the user to whom access was granted'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.OWNER IS 'Username of the owner of the object'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.COLUMN_NAME IS 'Name of the column'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.GRANTOR IS 'Name of the user who performed the grant'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.PRIVILEGE IS 'Column Privilege'
/
COMMENT ON COLUMN SYS.ALL_COL_PRIVS_MADE.GRANTABLE IS 'Privilege is grantable'
/

CREATE VIEW USER_LOG_GROUP_COLUMNS AS select u.name, c.name, o.name,
       decode(ac.name, null, col.name, ac.name), cc.pos#,
       decode(cc.spare1, 1, 'NO LOG', 'LOG')
from sys.user$ u, sys.con$ c, sys.col$ col, sys.ccol$ cc, sys.cdef$ cd,
     sys.obj$ o, sys.attrcol$ ac
where c.owner# = u.user#
  and c.con# = cd.con#
  and cd.type# = 12
  and cd.con# = cc.con#
  and cc.obj# = col.obj#
  and cc.intcol# = col.intcol#
  and cc.obj# = o.obj#
  and c.owner# = userenv('SCHEMAID')
  and col.obj# = ac.obj#(+)
  and col.intcol# = ac.intcol#(+)
/
COMMENT ON VIEW SYS.USER_LOG_GROUP_COLUMNS IS 'Information about columns in log group definitions'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.OWNER IS 'Owner of the log group definition'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.LOG_GROUP_NAME IS 'Name associated with the log group definition'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.TABLE_NAME IS 'Name associated with table with log group definition'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.COLUMN_NAME IS 'Name associated with column or attribute of object column specified in the log group definition'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.POSITION IS 'Original position of column or attribute in definition'
/
COMMENT ON COLUMN SYS.USER_LOG_GROUP_COLUMNS.LOGGING_PROPERTY IS 'Whether the column or attribute would be supplementally logged'
/

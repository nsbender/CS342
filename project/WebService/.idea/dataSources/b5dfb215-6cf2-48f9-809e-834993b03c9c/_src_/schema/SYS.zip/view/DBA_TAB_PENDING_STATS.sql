CREATE VIEW DBA_TAB_PENDING_STATS AS select u.name, o.name, null, null, h.rowcnt, h.blkcnt, h.avgrln,
         h.samplesize, h.analyzetime
  from   sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 2 and o.owner# = u.user#
    and  h.savtime > systimestamp
  union all
  -- partitions
  select u.name, o.name, o.subname, null, h.rowcnt, h.blkcnt,
         h.avgrln, h.samplesize, h.analyzetime
  from   sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 19 and o.owner# = u.user#
    and  h.savtime > systimestamp
  union all
  -- sub partitions
  select u.name, osp.name, ocp.subname, osp.subname, h.rowcnt,
         h.blkcnt, h.avgrln, h.samplesize, h.analyzetime
  from  sys.user$ u,  sys.obj$ osp, obj$ ocp,  sys.tabsubpart$ tsp,
        sys.wri$_optstat_tab_history h
  where h.obj# = osp.obj# and osp.type# = 34 and osp.obj# = tsp.obj# and
        tsp.pobj# = ocp.obj# and osp.owner# = u.user#
    and h.savtime > systimestamp
/
COMMENT ON VIEW SYS.DBA_TAB_PENDING_STATS IS 'Pending statistics of tables, partitions, and subpartitions'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.OWNER IS 'Name of the owner'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.PARTITION_NAME IS 'Name of the partition'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.SUBPARTITION_NAME IS 'Name of the subpartition'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.NUM_ROWS IS 'Number of rows'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.BLOCKS IS 'Number of blocks'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.AVG_ROW_LEN IS 'Average row length'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.SAMPLE_SIZE IS 'Sample size'
/
COMMENT ON COLUMN SYS.DBA_TAB_PENDING_STATS.LAST_ANALYZED IS 'Time of last analyze'
/

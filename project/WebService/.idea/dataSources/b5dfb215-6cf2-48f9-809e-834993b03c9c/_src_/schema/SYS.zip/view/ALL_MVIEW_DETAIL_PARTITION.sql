CREATE VIEW ALL_MVIEW_DETAIL_PARTITION AS select m."OWNER",m."MVIEW_NAME",m."DETAILOBJ_OWNER",m."DETAILOBJ_NAME",m."DETAIL_PARTITION_NAME",m."DETAIL_PARTITION_POSITION",m."FRESHNESS" from dba_mview_detail_partition m, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and m.mview_name = o.name
  and u.name       = m.owner
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/
COMMENT ON VIEW SYS.ALL_MVIEW_DETAIL_PARTITION IS 'Freshness information of all PCT materialized views in the database'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.OWNER IS 'Owner of the materialized view'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.DETAILOBJ_NAME IS 'Name of the detail object'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.DETAIL_PARTITION_NAME IS 'Name of the detail object partition'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.DETAIL_PARTITION_POSITION IS 'Position of the detail object partition'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_DETAIL_PARTITION.FRESHNESS IS 'Freshness of the detail object partition'
/

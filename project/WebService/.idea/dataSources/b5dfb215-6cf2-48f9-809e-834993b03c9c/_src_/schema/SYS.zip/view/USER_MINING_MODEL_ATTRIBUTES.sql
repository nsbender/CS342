CREATE VIEW USER_MINING_MODEL_ATTRIBUTES AS select o.name, a.name,
       decode(atyp, /* attribute type */
              1, 'NUMERICAL',
              2, 'CATEGORICAL',
              3, 'ORDINAL',
                 'UNDEFINED'),
       decode(dtyp, /* data type */
              1, 'VARCHAR2',
              2, 'NUMBER',
              4, 'FLOAT',
             96, 'CHAR',
            122, 'NESTED TABLE',
                 'UNDEFINED'),
       a.length,
       a.precision#,
       a.scale,
       decode(bitand(a.properties,1),1,'ACTIVE','INACTIVE'),
       decode(bitand(a.properties,2),2,'YES','NO')
from sys.modelatt$ a, sys.obj$ o
where o.obj#=a.mod#
  and o.owner#=userenv('SCHEMAID')
  and bitand(a.properties, 4) = 0
/
COMMENT ON VIEW SYS.USER_MINING_MODEL_ATTRIBUTES IS 'Description of the user''s own model attributes'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.MODEL_NAME IS 'Name of the model to which the attribute belongs'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.ATTRIBUTE_NAME IS 'Name of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.ATTRIBUTE_TYPE IS 'Mining type of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.DATA_TYPE IS 'Data type of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.DATA_LENGTH IS 'Data length of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.DATA_PRECISION IS 'Data precision of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.DATA_SCALE IS 'Data scale of the attribute'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_ATTRIBUTES.USAGE_TYPE IS 'Usage type for the attribute'
/

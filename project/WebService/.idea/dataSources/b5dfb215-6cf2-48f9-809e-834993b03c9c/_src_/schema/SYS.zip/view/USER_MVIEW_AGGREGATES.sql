CREATE VIEW USER_MVIEW_AGGREGATES AS select u.name, o.name, sa.sumcolpos#, c.name,
       decode(sa.aggfunction, 15, 'AVG', 16, 'SUM', 17, 'COUNT',
                              18, 'MIN', 19, 'MAX',
                              97, 'VARIANCE', 98, 'STDDEV',
                              440, 'USER'),
       decode(sa.flags, 0, 'N', 'Y'),
       sa.aggtext
from sys.sumagg$ sa, sys.obj$ o, sys.user$ u, sys.sum$ s, sys.col$ c
where sa.sumobj# = o.obj#
  AND o.owner# = u.user#
  AND sa.sumobj# = s.obj#
  AND c.obj# = s.containerobj#
  AND c.col# = sa.containercol#
  AND o.owner# = userenv('SCHEMAID')
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/
COMMENT ON VIEW SYS.USER_MVIEW_AGGREGATES IS 'Description of the materialized view aggregates created by the user'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.OWNER IS 'Owner of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.POSITION_IN_SELECT IS 'Position of this aggregated measure with the SELECT list'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.CONTAINER_COLUMN IS 'Name of this column in the container table'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.AGG_FUNCTION IS 'Name of the aggregation function, one of the following:
COUNT, SUM, MIN, MAX, AVG, VARIANCE, STDDEV'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.DISTINCTFLAG IS 'Set to Y is this is a DISTINCT aggregation'
/
COMMENT ON COLUMN SYS.USER_MVIEW_AGGREGATES.MEASURE IS 'The SQL text of the measure, excluding the aggregation function'
/

CREATE VIEW USER_INDEXTYPES AS select u.name, o.name, u1.name, o1.name, i.interface_version#, t.version#,
io.opcount, decode(bitand(i.property, 48), 0, 'NONE', 16, 'RANGE', 32, 'LOCAL     '),
decode(bitand(i.property, 2), 0, 'NO', 2, 'YES'),
decode(bitand(i.property, 1024), 0, 'USER_MANAGED', 1024, 'SYSTEM_MANAGED')
from sys.indtypes$ i, sys.user$ u, sys.obj$ o,
sys.user$ u1, (select it.obj#, count(*) opcount from
sys.indop$ io1, sys.indtypes$ it where
io1.obj# = it.obj# and bitand(io1.property, 4) != 4
group by it.obj#) io, sys.obj$ o1,
sys.type$ t
where i.obj# = o.obj# and o.owner# = u.user# and
u1.user# = o.owner# and io.obj# = i.obj# and
o1.obj# = i.implobj# and o1.oid$ = t.toid and
o.owner# = userenv ('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_INDEXTYPES IS 'All user indextypes'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.OWNER IS 'Owner of the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.INDEXTYPE_NAME IS 'Name of the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.IMPLEMENTATION_SCHEMA IS 'Name of the schema for indextype implementation'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.IMPLEMENTATION_NAME IS 'Name of indextype implementation'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.INTERFACE_VERSION IS 'Version of indextype interface'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.IMPLEMENTATION_VERSION IS 'Version of indextype implementation'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.NUMBER_OF_OPERATORS IS 'Number of operators associated with the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.PARTITIONING IS 'Kinds of local partitioning supported by the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.ARRAY_DML IS 'Does this indextype support array dml'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPES.MAINTENANCE_TYPE IS 'An indicator of whether the indextype is system managed or user managed'
/

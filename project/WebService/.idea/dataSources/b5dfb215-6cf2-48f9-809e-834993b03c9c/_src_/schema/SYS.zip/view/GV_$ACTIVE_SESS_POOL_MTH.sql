CREATE VIEW GV_$ACTIVE_SESS_POOL_MTH AS select "INST_ID","NAME" from gv$active_sess_pool_mth
/

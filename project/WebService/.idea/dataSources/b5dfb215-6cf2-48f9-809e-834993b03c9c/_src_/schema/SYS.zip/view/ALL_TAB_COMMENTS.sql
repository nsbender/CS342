CREATE VIEW ALL_TAB_COMMENTS AS select u.name, o.name,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 'UNDEFINED'),
       c.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.com$ c
where o.owner# = u.user#
  and o.obj# = c.obj#(+)
  and c.col#(+) is null
  and bitand(o.flags, 128) = 0
  and (o.type# in (4)                                                /* view */
       or
       (o.type# = 2                                                /* tables */
        AND         /* excluding iot-overflow, nested or mv container tables */
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192 OR
                            bitand(t.property, 67108864) = 67108864))))
  and (o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                  )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
       )
/
COMMENT ON VIEW SYS.ALL_TAB_COMMENTS IS 'Comments on tables and views accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_TAB_COMMENTS.OWNER IS 'Owner of the object'
/
COMMENT ON COLUMN SYS.ALL_TAB_COMMENTS.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.ALL_TAB_COMMENTS.TABLE_TYPE IS 'Type of the object'
/
COMMENT ON COLUMN SYS.ALL_TAB_COMMENTS.COMMENTS IS 'Comment on the object'
/

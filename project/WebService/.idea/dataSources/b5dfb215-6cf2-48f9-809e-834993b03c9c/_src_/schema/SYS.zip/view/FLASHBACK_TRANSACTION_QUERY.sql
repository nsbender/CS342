CREATE VIEW FLASHBACK_TRANSACTION_QUERY AS select xid, start_scn, start_timestamp,
          decode(commit_scn, 0, commit_scn, 281474976710655, NULL, commit_scn)
          commit_scn, commit_timestamp,
          logon_user, undo_change#, operation, table_name, table_owner,
          row_id, undo_sql
from sys.x$ktuqqry
/
COMMENT ON VIEW SYS.FLASHBACK_TRANSACTION_QUERY IS 'Description of the flashback transaction query view'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.XID IS 'Transaction identifier'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.START_SCN IS 'Transaction start SCN'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.START_TIMESTAMP IS 'Transaction start timestamp'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.COMMIT_SCN IS 'Transaction commit SCN'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.COMMIT_TIMESTAMP IS 'Transaction commit timestamp'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.LOGON_USER IS 'Logon user for transaction'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.UNDO_CHANGE# IS '1-based undo change number'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.OPERATION IS 'forward operation for this undo'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.TABLE_NAME IS 'table name to which this undo applies'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.TABLE_OWNER IS 'owner of table to which this undo applies'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.ROW_ID IS 'rowid to which this undo applies'
/
COMMENT ON COLUMN SYS.FLASHBACK_TRANSACTION_QUERY.UNDO_SQL IS 'SQL corresponding to this undo'
/

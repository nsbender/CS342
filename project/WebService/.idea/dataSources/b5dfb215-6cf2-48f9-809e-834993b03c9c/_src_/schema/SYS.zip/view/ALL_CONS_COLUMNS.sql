CREATE VIEW ALL_CONS_COLUMNS AS select u.name, c.name, o.name,
       decode(ac.name, null, col.name, ac.name), cc.pos#
from sys.user$ u, sys.con$ c, sys.col$ col, sys.ccol$ cc, sys.cdef$ cd,
     sys."_CURRENT_EDITION_OBJ" o, sys.attrcol$ ac
where c.owner# = u.user#
  and c.con# = cd.con#
  and (cd.type# < 14 or cd.type# > 17)   /* don't include supplog cons   */
  and (cd.type# != 12)                   /* don't include log group cons */
  and cd.con# = cc.con#
  and cc.obj# = col.obj#
  and cc.intcol# = col.intcol#
  and cc.obj# = o.obj#
  and (c.owner# = userenv('SCHEMAID')
       or cd.obj# in (select obj#
                      from sys.objauth$
                      where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                     )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
  and col.obj# = ac.obj#(+)
  and col.intcol# = ac.intcol#(+)
/
COMMENT ON VIEW SYS.ALL_CONS_COLUMNS IS 'Information about accessible columns in constraint definitions'
/
COMMENT ON COLUMN SYS.ALL_CONS_COLUMNS.OWNER IS 'Owner of the constraint definition'
/
COMMENT ON COLUMN SYS.ALL_CONS_COLUMNS.CONSTRAINT_NAME IS 'Name associated with the constraint definition'
/
COMMENT ON COLUMN SYS.ALL_CONS_COLUMNS.TABLE_NAME IS 'Name associated with table with constraint definition'
/
COMMENT ON COLUMN SYS.ALL_CONS_COLUMNS.COLUMN_NAME IS 'Name associated with column or attribute of object column specified in the constraint definition'
/
COMMENT ON COLUMN SYS.ALL_CONS_COLUMNS.POSITION IS 'Original position of column or attribute in definition'
/

CREATE VIEW USER_OLDIMAGE_COLUMNS AS select u.name, o.name,
       decode(c.name, 'SYS_NC_ROWINFO$', 'OBJECT TABLE', c.name)
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.coltype$ t
where o.type# = 2 and    /* show only tables */
      o.owner# = userenv('SCHEMAID') and
      o.owner# = u.user# and
      o.obj# = c.obj# and
      o.obj# = t.obj# and
      c.intcol# = t.intcol# and
      /* do not show attribute columns. If the attribute is in 8.0 image, that
        means the whole column is in 8.0 image. Now, this will still show
        top level ADT columns in an object table, which is redundant. */
      bitand(c.property, 1) = 0  and
      bitand(t.flags, 128) <> 0
/
COMMENT ON VIEW SYS.USER_OLDIMAGE_COLUMNS IS 'Gives all object tables and columns in old (8.0) image format'
/
COMMENT ON COLUMN SYS.USER_OLDIMAGE_COLUMNS.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.USER_OLDIMAGE_COLUMNS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_OLDIMAGE_COLUMNS.COLUMN_NAME IS 'Name of the top-level column'
/

CREATE VIEW INDEX_STATS AS select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln+kdxstpln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, ind$ i, seg$ s, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = i.file#
  and  s.block# = i.block#
  and  s.ts# = i.ts#
  and  i.obj#   = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, seg$ s, indpart$ ip, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = ip.file#
  and  s.block# = ip.block#
  and  s.ts#    = ip.ts#
  and  ip.obj#  = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, seg$ s, indsubpart$ isp, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = isp.file#
  and  s.block# = isp.block#
  and  s.ts#    = isp.ts#
  and  isp.obj#  = o.obj#
/
COMMENT ON VIEW SYS.INDEX_STATS IS 'statistics on the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.HEIGHT IS 'height of the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BLOCKS IS 'blocks allocated to the segment'
/
COMMENT ON COLUMN SYS.INDEX_STATS.NAME IS 'name of the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.PARTITION_NAME IS 'name of the index partition, if partitioned'
/
COMMENT ON COLUMN SYS.INDEX_STATS.LF_ROWS IS 'number of leaf rows (values in the index)'
/
COMMENT ON COLUMN SYS.INDEX_STATS.LF_BLKS IS 'number of leaf blocks in the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.LF_ROWS_LEN IS 'sum of the lengths of all the leaf rows'
/
COMMENT ON COLUMN SYS.INDEX_STATS.LF_BLK_LEN IS 'useable space in a leaf block'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BR_ROWS IS 'number of branch rows'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BR_BLKS IS 'number of branch blocks in the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BR_ROWS_LEN IS 'sum of the lengths of all the branch blocks in the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BR_BLK_LEN IS 'useable space in a branch block'
/
COMMENT ON COLUMN SYS.INDEX_STATS.DEL_LF_ROWS IS 'number of deleted leaf rows in the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.DEL_LF_ROWS_LEN IS 'total length of all deleted rows in the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.DISTINCT_KEYS IS 'number of distinct keys in the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.MOST_REPEATED_KEY IS 'how many times the most repeated key is repeated'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BTREE_SPACE IS 'total space currently allocated in the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.USED_SPACE IS 'total space that is currently being used in the b-tree'
/
COMMENT ON COLUMN SYS.INDEX_STATS.PCT_USED IS 'percent of space allocated in the b-tree that is being used'
/
COMMENT ON COLUMN SYS.INDEX_STATS.ROWS_PER_KEY IS 'average number of rows per distinct key'
/
COMMENT ON COLUMN SYS.INDEX_STATS.BLKS_GETS_PER_ACCESS IS 'Expected number of consistent mode block gets per row. This assumes that a row chosen at random from the table is being searched for using the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.PRE_ROWS IS 'number of prefix rows (values in the index)'
/
COMMENT ON COLUMN SYS.INDEX_STATS.PRE_ROWS_LEN IS 'sum of lengths of all prefix rows'
/
COMMENT ON COLUMN SYS.INDEX_STATS.OPT_CMPR_COUNT IS 'optimal prefix compression count for the index'
/
COMMENT ON COLUMN SYS.INDEX_STATS.OPT_CMPR_PCTSAVE IS 'percentage storage saving expected from optimal prefix compression'
/

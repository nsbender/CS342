CREATE VIEW USER_CONSTRAINTS AS select ou.name, oc.name,
       decode(c.type#, 1, 'C', 2, 'P', 3, 'U',
              4, 'R', 5, 'V', 6, 'O', 7,'C', 8, 'H', 9, 'F',
              10, 'F', 11, 'F', 13, 'F', '?'),
       o.name, c.condition, ru.name, rc.name,
       decode(c.type#, 4,
              decode(c.refact, 1, 'CASCADE', 2, 'SET NULL', 'NO ACTION'),
              NULL),
       decode(c.type#, 5, 'ENABLED',
              decode(c.enabled, NULL, 'DISABLED', 'ENABLED')),
       decode(bitand(c.defer, 1), 1, 'DEFERRABLE', 'NOT DEFERRABLE'),
       decode(bitand(c.defer, 2), 2, 'DEFERRED', 'IMMEDIATE'),
       decode(bitand(c.defer, 4), 4, 'VALIDATED', 'NOT VALIDATED'),
       decode(bitand(c.defer, 8), 8, 'GENERATED NAME', 'USER NAME'),
       decode(bitand(c.defer,16),16, 'BAD', null),
       decode(bitand(c.defer,32),32, 'RELY', null),
       c.mtime,
       decode(c.type#, 2, ui.name, 3, ui.name, null),
       decode(c.type#, 2, oi.name, 3, oi.name, null),
       decode(bitand(c.defer, 256), 256,
              decode(c.type#, 4,
                     case when (bitand(c.defer, 128) = 128
                                or o.status in (3, 5)
                                or ro.status in (3, 5)) then 'INVALID'
                          else null end,
                     case when (bitand(c.defer, 128) = 128
                                or o.status in (3, 5)) then 'INVALID'
                          else null end
                    ),
              null),
       decode(bitand(c.defer, 256), 256, 'DEPEND ON VIEW', null)
from sys.con$ oc, sys.con$ rc, sys."_BASE_USER" ou, sys."_BASE_USER" ru,
     sys."_CURRENT_EDITION_OBJ" ro, sys."_CURRENT_EDITION_OBJ" o, sys.cdef$ c,
     sys.obj$ oi, sys.user$ ui
where oc.owner# = ou.user#
  and oc.con# = c.con#
  and c.obj# = o.obj#
  and c.rcon# = rc.con#(+)
  and c.enabled = oi.obj#(+)
  and oi.owner# = ui.user#(+)
  and rc.owner# = ru.user#(+)
  and c.robj# = ro.obj#(+)
  and o.owner# = userenv('SCHEMAID')
  and c.type# != 8
  and (c.type# < 14 or c.type# > 17)    /* don't include supplog cons   */
  and (c.type# != 12)                   /* don't include log group cons */
/
COMMENT ON VIEW SYS.USER_CONSTRAINTS IS 'Constraint definitions on user''s own tables'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.CONSTRAINT_NAME IS 'Name associated with constraint definition'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.CONSTRAINT_TYPE IS 'Type of constraint definition'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.TABLE_NAME IS 'Name associated with table with constraint definition'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.SEARCH_CONDITION IS 'Text of search condition for table check'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.R_OWNER IS 'Owner of table used in referential constraint'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.R_CONSTRAINT_NAME IS 'Name of unique constraint definition for referenced table'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.DELETE_RULE IS 'The delete rule for a referential constraint'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.STATUS IS 'Enforcement status of constraint -  ENABLED or DISABLED'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.DEFERRABLE IS 'Is the constraint deferrable - DEFERRABLE or NOT DEFERRABLE'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.DEFERRED IS 'Is the constraint deferred by default -  DEFERRED or IMMEDIATE'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.VALIDATED IS 'Was this constraint system validated? -  VALIDATED or NOT VALIDATED'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.GENERATED IS 'Was the constraint name system generated? -  GENERATED NAME or USER NAME'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.BAD IS 'Creating this constraint should give ORA-02436.  Rewrite it before 2000 AD.'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.RELY IS 'If set, this flag will be used in optimizer'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.LAST_CHANGE IS 'The date when this column was last enabled or disabled'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.INDEX_OWNER IS 'The owner of the index used by the constraint'
/
COMMENT ON COLUMN SYS.USER_CONSTRAINTS.INDEX_NAME IS 'The index used by the constraint'
/

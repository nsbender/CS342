CREATE VIEW V$OBJECT_USAGE AS select io.name, t.name,
       decode(bitand(i.flags, 65536), 0, 'NO', 'YES'),
       decode(bitand(ou.flags, 1), 0, 'NO', 'YES'),
       ou.start_monitoring,
       ou.end_monitoring
from sys.obj$ io, sys.obj$ t, sys.ind$ i, sys.object_usage ou
where io.owner# = userenv('SCHEMAID')
  and i.obj# = ou.obj#
  and io.obj# = ou.obj#
  and t.obj# = i.bo#
/
COMMENT ON VIEW SYS.V$OBJECT_USAGE IS 'Record of index usage'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.INDEX_NAME IS 'Name of the index'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.TABLE_NAME IS 'Name of the table upon which the index was build'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.MONITORING IS 'Whether the monitoring feature is on'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.USED IS 'Whether the index has been accessed'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.START_MONITORING IS 'When the monitoring feature is turned on'
/
COMMENT ON COLUMN SYS.V$OBJECT_USAGE.END_MONITORING IS 'When the monitoring feature is turned off'
/

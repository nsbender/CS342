CREATE VIEW ROLE_ROLE_PRIVS AS select u1.name,u2.name,decode(min(option$),1,'YES','NO')
from  sys.user$ u1, sys.user$ u2, sys.sysauth$ sa
where grantee# in
   (select distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
   and u1.user#=sa.grantee# and u2.user#=sa.privilege#
group by u1.name,u2.name
/
COMMENT ON VIEW SYS.ROLE_ROLE_PRIVS IS 'Roles which are granted to roles'
/
COMMENT ON COLUMN SYS.ROLE_ROLE_PRIVS.ROLE IS 'Role Name'
/
COMMENT ON COLUMN SYS.ROLE_ROLE_PRIVS.GRANTED_ROLE IS 'Role which was granted'
/
COMMENT ON COLUMN SYS.ROLE_ROLE_PRIVS.ADMIN_OPTION IS 'Grant was with the ADMIN option'
/

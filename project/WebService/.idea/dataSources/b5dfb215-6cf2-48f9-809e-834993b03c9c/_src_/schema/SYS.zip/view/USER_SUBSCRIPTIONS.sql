CREATE VIEW USER_SUBSCRIPTIONS AS SELECT
   s.handle, s.set_name, s.username, s.created, s.status, s.earliest_scn,
   s.latest_scn, s.description, s.last_purged, s.last_extended,
   s.subscription_name
  FROM sys.cdc_subscribers$ s, sys.user$ u
  WHERE s.username= u.name AND
        u.user#   = USERENV('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_SUBSCRIPTIONS IS 'Change Data Capture subscriptions'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.HANDLE IS 'Unique identifier of the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.SET_NAME IS 'Change set for the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.USERNAME IS 'User name of the subscriber'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.CREATED IS 'Creation date of the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.STATUS IS 'Status of the subscriptions (N not activated, A activated)'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.EARLIEST_SCN IS 'Subscription window low boundary'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.LATEST_SCN IS 'Subscription window high boundary'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.DESCRIPTION IS 'Description of the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.LAST_PURGED IS 'Last time subscriber called purge_window'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.LAST_EXTENDED IS 'Last time subscriber called extend_window'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIPTIONS.SUBSCRIPTION_NAME IS 'Name of the subscription'
/

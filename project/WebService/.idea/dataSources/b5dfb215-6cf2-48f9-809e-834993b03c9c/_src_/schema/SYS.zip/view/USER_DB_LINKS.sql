CREATE VIEW USER_DB_LINKS AS select l.name, l.userid, l.password, l.host, l.ctime
from sys.link$ l
where l.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_DB_LINKS IS 'Database links owned by the user'
/
COMMENT ON COLUMN SYS.USER_DB_LINKS.DB_LINK IS 'Name of the database link'
/
COMMENT ON COLUMN SYS.USER_DB_LINKS.USERNAME IS 'Name of user to log on as'
/
COMMENT ON COLUMN SYS.USER_DB_LINKS.PASSWORD IS 'Deprecated-Password for logon'
/
COMMENT ON COLUMN SYS.USER_DB_LINKS.HOST IS 'SQL*Net string for connect'
/
COMMENT ON COLUMN SYS.USER_DB_LINKS.CREATED IS 'Creation time of the database link'
/

CREATE VIEW ALL_EDITIONING_VIEW_COLS AS select ev_user.name,
       ev_obj.name,
       view_col.col#,
       view_col.name,
       tbl_col.col#,
       tbl_col.name
from   sys."_CURRENT_EDITION_OBJ" ev_obj, sys.obj$ base_tbl_obj,
       sys.ev$ ev, sys.evcol$ ev_col, sys.col$ view_col, sys.col$ tbl_col,
       sys.user$ ev_user
where  /* get all columns of a given EV */
       ev.ev_obj# = ev_col.ev_obj#
       /* join EVCOL$ to COL$ on EV id and column id to obtain EV column */
       /* name */
  and  ev_col.ev_obj# = view_col.obj#
  and  ev_col.ev_col_id = view_col.col#
       /* join EV$ to OBJ$ on base table owner id and base table name so we */
       /* can determine base table id */
  and  ev.base_tbl_owner# = base_tbl_obj.owner#
  and  ev.base_tbl_name   = base_tbl_obj.name
       /* exclude [sub]partitions by restricting base_tbl_obj.type# to */
       /* "table"; since COL$ will not contain rows for [sub]partitions, */
       /* this restriction is not, strictly speaking, necessary, but it */
       /* does ensure that the above join will return exactly one row */
  and base_tbl_obj.type# = 2
       /* join EVCOL$ row and OBJ$ row describing the EV's base table to */
       /* COL$ to obtain base table column id */
  and  base_tbl_obj.obj# = tbl_col.obj#
  and  ev_col.base_tbl_col_name = tbl_col.name
       /* join EV$ to _CURRENT_EDITION_OBJ on EV id so we can determine */
       /* name of the EV and id of its owner */
  and  ev_obj.obj# = ev.ev_obj#
       /* join _CURRENT_EDITION_OBJ row describing the EV to USER$ to get */
       /* owner name */
   and ev_obj.owner# = ev_user.user#
       /* make sure the EV is visible to the current user */
   and (ev_obj.owner# = userenv('SCHEMAID')
        or ev_obj.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
/
COMMENT ON VIEW SYS.ALL_EDITIONING_VIEW_COLS IS 'Relationship between columns of Editioning Views accessible to the user and the table columns to which they map'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.OWNER IS 'Owner of an Editioning View'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.VIEW_NAME IS 'Name of an Editioning View'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.VIEW_COLUMN_ID IS 'Column number within the Editioning View'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.VIEW_COLUMN_NAME IS 'Name of the column in the Editioning View'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.TABLE_COLUMN_ID IS 'Column number of a table column to which this EV column maps'
/
COMMENT ON COLUMN SYS.ALL_EDITIONING_VIEW_COLS.TABLE_COLUMN_NAME IS 'Name of a table column to which this EV column maps'
/

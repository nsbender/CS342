CREATE VIEW ALL_OPERATOR_COMMENTS AS select u.name, o.name, c.comment$
from   sys.obj$ o, sys.operator$ op, sys.com$ c, sys.user$ u
where  o.obj# = op.obj# and c.obj# = op.obj# and u.user# = o.owner#
       and
       ( o.owner# = userenv('SCHEMAID')
         or
         o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
         or exists (select null from v$enabledprivs
                    where priv_number in (-200 /* CREATE OPERATOR */,
                                        -201 /* CREATE ANY OPERATOR */,
                                        -202 /* ALTER ANY OPERATOR */,
                                        -203 /* DROP ANY OPERATOR */,
                                        -204 /* EXECUTE OPERATOR */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_OPERATOR_COMMENTS IS 'Comments for user-defined operators'
/
COMMENT ON COLUMN SYS.ALL_OPERATOR_COMMENTS.OWNER IS 'Owner of the user-defined operator'
/
COMMENT ON COLUMN SYS.ALL_OPERATOR_COMMENTS.OPERATOR_NAME IS 'Name of the user-defined operator'
/
COMMENT ON COLUMN SYS.ALL_OPERATOR_COMMENTS.COMMENTS IS 'Comment for the user-defined operator'
/

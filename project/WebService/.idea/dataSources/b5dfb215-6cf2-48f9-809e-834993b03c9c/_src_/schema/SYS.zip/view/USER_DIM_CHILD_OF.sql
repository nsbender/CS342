CREATE VIEW USER_DIM_CHILD_OF AS select d."OWNER",d."DIMENSION_NAME",d."HIERARCHY_NAME",d."POSITION",d."CHILD_LEVEL_NAME",d."JOIN_KEY_ID",d."PARENT_LEVEL_NAME" FROM dba_dim_child_of d, sys.user$ u
where u.user# = userenv('SCHEMAID')
  and d.owner = u.name
/
COMMENT ON VIEW SYS.USER_DIM_CHILD_OF IS 'Representaion of a 1:n hierarchical relationship between a pair of levels in
 a dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.HIERARCHY_NAME IS 'Name of the hierarchy'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.POSITION IS 'Hierarchical position within this hierarchy, position 1 being
 the most detailed'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.CHILD_LEVEL_NAME IS 'Name of the child-side level of this 1:n relationship'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.JOIN_KEY_ID IS 'Keys that join child to the parent'
/
COMMENT ON COLUMN SYS.USER_DIM_CHILD_OF.PARENT_LEVEL_NAME IS 'Name of the parent-side level of this 1:n relationship'
/

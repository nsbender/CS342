CREATE VIEW USER_VARRAYS AS select distinct op.name, ac.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       NULL,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys."_CURRENT_EDITION_OBJ" op, sys.obj$ ot, sys.col$ c,
  sys.coltype$ ct, sys.user$ u, sys."_BASE_USER" ut, sys.attrcol$ ac, sys.type$ t,
  sys.collection$ cl
where op.owner# = userenv('SCHEMAID')
  and c.obj# = op.obj#
  and c.obj# = ac.obj#
  and c.intcol# = ac.intcol#
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol# = c.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8) = 8
  and bitand(c.property, 128) != 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select distinct op.name, ac.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       o.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.lob$ l, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" op,
  sys.obj$ ot, sys.col$ c, sys.coltype$ ct, sys.user$ u,
  sys."_BASE_USER" ut, sys.attrcol$ ac, sys.type$ t, sys.collection$ cl
where o.owner# = userenv('SCHEMAID')
  and l.obj# = op.obj#
  and l.lobj# = o.obj#
  and c.obj# = op.obj#
  and l.intcol# = c.intcol#
  and c.obj# = ac.obj#
  and c.intcol# = ac.intcol#
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=l.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8) = 8
  and bitand(c.property, 128) = 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select op.name, c.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       NULL,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys."_CURRENT_EDITION_OBJ" op, sys.obj$ ot, sys.col$ c,
  sys.coltype$ ct, sys."_BASE_USER" ut, sys.type$ t, sys.collection$ cl
where op.owner# = userenv('SCHEMAID')
  and c.obj# = op.obj#
  and bitand(c.property,1)=0
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol# = c.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8)=8
  and bitand(c.property, 128) != 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select op.name, c.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       o.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.lob$ l, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" op,
  sys.obj$ ot, sys.col$ c, sys.coltype$ ct, sys."_BASE_USER" ut,
  sys.type$ t, sys.collection$ cl
where o.owner# = userenv('SCHEMAID')
  and l.obj# = op.obj#
  and l.lobj# = o.obj#
  and c.obj# = op.obj#
  and l.intcol# = c.intcol#
  and bitand(c.property,1)=0
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=l.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8)=8
  and bitand(c.property, 128) = 128
  and bitand(c.property,32768) != 32768           /* not unused column */
/
COMMENT ON VIEW SYS.USER_VARRAYS IS 'Description of varrays contained in the user''s own tables'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.PARENT_TABLE_NAME IS 'Name of the parent table containing the varray'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.PARENT_TABLE_COLUMN IS 'Column name of the parent table that corresponds to the varray'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.TYPE_OWNER IS 'Owner of the type of which the varray was created'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.TYPE_NAME IS 'Name of the type of the varray'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.LOB_NAME IS 'Name of the lob if varray is stored in a lob'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.STORAGE_SPEC IS 'Indication of default or user-specified storage for the varray'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.RETURN_TYPE IS 'Return type of the varray column locator or value'
/
COMMENT ON COLUMN SYS.USER_VARRAYS.ELEMENT_SUBSTITUTABLE IS 'Indication of whether the varray element is substitutable or not'
/

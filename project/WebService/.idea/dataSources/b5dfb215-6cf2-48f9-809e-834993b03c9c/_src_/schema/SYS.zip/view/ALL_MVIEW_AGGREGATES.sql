CREATE VIEW ALL_MVIEW_AGGREGATES AS select u.name, o.name, sa.sumcolpos#, c.name,
       decode(sa.aggfunction, 15, 'AVG', 16, 'SUM', 17, 'COUNT',
                              18, 'MIN', 19, 'MAX',
                              97, 'VARIANCE', 98, 'STDDEV',
                              440, 'USER'),
       decode(sa.flags, 0, 'N', 'Y'),
       sa.aggtext
from sys.sumagg$ sa, sys.obj$ o, sys.user$ u, sys.sum$ s, sys.col$ c
where sa.sumobj# = o.obj#
  AND o.owner# = u.user#
  AND sa.sumobj# = s.obj#
  AND c.obj# = s.containerobj#
  AND c.col# = sa.containercol#
  AND (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/
COMMENT ON VIEW SYS.ALL_MVIEW_AGGREGATES IS 'Description of the materialized view aggregates accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.OWNER IS 'Owner of the materialized view'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.POSITION_IN_SELECT IS 'Position of this aggregated measure with the SELECT list'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.CONTAINER_COLUMN IS 'Name of this column in the container table'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.AGG_FUNCTION IS 'Name of the aggregation function, one of the following:
COUNT, SUM, MIN, MAX, AVG, VARIANCE, STDDEV'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.DISTINCTFLAG IS 'Set to Y is this is a DISTINCT aggregation'
/
COMMENT ON COLUMN SYS.ALL_MVIEW_AGGREGATES.MEASURE IS 'The SQL text of the measure, excluding the aggregation function'
/

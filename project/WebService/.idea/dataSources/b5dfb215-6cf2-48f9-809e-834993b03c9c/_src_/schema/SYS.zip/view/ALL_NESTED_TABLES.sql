CREATE VIEW ALL_NESTED_TABLES AS select u.name, o.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       op.name, ac.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.ntab$ n, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" op,
  sys.obj$ ot, sys.col$ c, sys.coltype$ ct, sys.user$ u,
  sys."_BASE_USER" ut, sys.attrcol$ ac, sys.type$ t, sys.collection$ cl
where o.owner# = u.user#
  and op.owner# = u.user#
  and n.obj# = op.obj#
  and n.ntab# = o.obj#
  and c.obj# = op.obj#
  and n.intcol# = c.intcol#
  and c.obj# = ac.obj#
  and c.intcol# = ac.intcol#
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=n.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,4)=4
  and bitand(c.property,32768) != 32768           /* not unused column */
  and bitand(o.flags,128) = 0                     /* not in recycle bin */
  and (op.owner# = userenv('SCHEMAID')
       or op.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
union all
select u.name, o.name,
       nvl2(ct.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o where o.obj#=ct.synobj#),
            ot.name),
       op.name, c.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.ntab$ n, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" op,
  sys.obj$ ot, sys.col$ c,  sys.coltype$ ct, sys.user$ u,
  sys."_BASE_USER" ut, sys.type$ t, sys.collection$ cl
where o.owner# = u.user#
  and op.owner# = u.user#
  and n.obj# = op.obj#
  and n.ntab# = o.obj#
  and c.obj# = op.obj#
  and n.intcol# = c.intcol#
  and bitand(c.property,1)=0
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=n.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,4)=4
  and bitand(c.property,32768) != 32768           /* not unused column */
  and bitand(o.flags,128) = 0                     /* not in recycle bin */
  and (op.owner# = userenv('SCHEMAID')
       or op.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_NESTED_TABLES IS 'Description of nested tables in tables accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.OWNER IS 'Owner of the nested table'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.TABLE_NAME IS 'Name of the nested table'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.TABLE_TYPE_OWNER IS 'Owner of the type of which the nested table was created'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.TABLE_TYPE_NAME IS 'Name of the type of the nested table'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.PARENT_TABLE_NAME IS 'Name of the parent table containing the nested table'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.PARENT_TABLE_COLUMN IS 'Column name of the parent table that corresponds to the nested table'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLES.ELEMENT_SUBSTITUTABLE IS 'Indication of whether the nested table element is substitutable or not'
/

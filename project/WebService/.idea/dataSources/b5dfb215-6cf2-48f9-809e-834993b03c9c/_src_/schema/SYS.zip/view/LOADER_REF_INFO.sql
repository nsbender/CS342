CREATE VIEW LOADER_REF_INFO AS select owner, table_name, object_id_type
        from all_object_tables
/

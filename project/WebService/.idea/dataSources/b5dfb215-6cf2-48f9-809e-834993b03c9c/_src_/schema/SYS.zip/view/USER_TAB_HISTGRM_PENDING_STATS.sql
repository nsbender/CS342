CREATE VIEW USER_TAB_HISTGRM_PENDING_STATS AS select o.name, null, null, c.name,
         h.bucket,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.endpoint
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.epvalue
              else null
         end
  from   sys.user$ u, sys.obj$ o, sys.col$ c,
         sys.wri$_optstat_histgrm_history h
  where  h.obj# = c.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.owner# = u.user#
    and  o.type# = 2
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  -- partitions
  select o.name, o.subname, null, c.name,
         h.bucket,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.endpoint
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.epvalue
              else null
         end
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabpart$ t,
         sys.wri$_optstat_histgrm_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  select o.name, o.subname, null, c.name,
         h.bucket,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.endpoint
              else null
         end,
         case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
              then h.epvalue
              else null
         end
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabcompart$ t,
         sys.wri$_optstat_histgrm_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  -- sub partitions
  select op.name, op.subname, os.subname, c.name,
         h.bucket,
         case when SYS_OP_DV_CHECK(os.name, os.owner#) = 1
              then h.endpoint
              else null
         end,
         case when SYS_OP_DV_CHECK(os.name, os.owner#) = 1
              then h.epvalue
              else null
         end
  from  sys.obj$ os, sys.tabsubpart$ tsp, sys.tabcompart$ tcp,
        sys.col$ c, sys.obj$ op,
        sys.wri$_optstat_histgrm_history h
  where os.obj# = tsp.obj#
    and h.obj#  = tsp.obj#
    and h.intcol#= c.intcol#
    and tsp.pobj#= tcp.obj#
    and tcp.bo#  = c.obj#
    and tcp.obj# = op.obj#
    and os.type# = 34
    and h.savtime > systimestamp
    and os.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_TAB_HISTGRM_PENDING_STATS IS 'Pending statistics of tables, partitions, and subpartitions'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.PARTITION_NAME IS 'Name of the partition'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.SUBPARTITION_NAME IS 'Name of the subpartition'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.COLUMN_NAME IS 'Name of the column'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.ENDPOINT_NUMBER IS 'Endpoint number'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.ENDPOINT_VALUE IS 'Normalized endpoint value'
/
COMMENT ON COLUMN SYS.USER_TAB_HISTGRM_PENDING_STATS.ENDPOINT_ACTUAL_VALUE IS 'Actual endpoint value'
/

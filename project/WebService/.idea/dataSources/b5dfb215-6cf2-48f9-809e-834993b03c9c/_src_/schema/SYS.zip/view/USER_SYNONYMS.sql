CREATE VIEW USER_SYNONYMS AS select o.name, s.owner, s.name, s.node
from sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_SYNONYMS IS 'The user''s private synonyms'
/
COMMENT ON COLUMN SYS.USER_SYNONYMS.SYNONYM_NAME IS 'Name of the synonym'
/
COMMENT ON COLUMN SYS.USER_SYNONYMS.TABLE_OWNER IS 'Owner of the object referenced by the synonym'
/
COMMENT ON COLUMN SYS.USER_SYNONYMS.TABLE_NAME IS 'Name of the object referenced by the synonym'
/
COMMENT ON COLUMN SYS.USER_SYNONYMS.DB_LINK IS 'Database link referenced in a remote synonym'
/

CREATE VIEW EXU8BSZ AS SELECT  ts$.blocksize
        FROM    sys.ts$ ts$
/

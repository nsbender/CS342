CREATE VIEW USER_OPANCILLARY AS select distinct u.name, o.name, a.bind#, u1.name, o1.name, a1.primbind#
from   sys.user$ u, sys.obj$ o, sys.opancillary$ a, sys.user$ u1, sys.obj$ o1,
       sys.opancillary$ a1
where  a.obj#=o.obj# and o.owner#=u.user#   AND
       a1.primop#=o1.obj# and o1.owner#=u1.user# and a.obj#=a1.obj#
       and o.owner#=userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_OPANCILLARY IS 'All ancillary opertors defined by user'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.OWNER IS 'Owner of ancillary operator'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.OPERATOR_NAME IS 'Name of ancillary operator'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.BINDING# IS 'Binding number of ancillary operator'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.PRIMOP_OWNER IS 'Owner of primary operator'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.PRIMOP_NAME IS 'Name of primary operator'
/
COMMENT ON COLUMN SYS.USER_OPANCILLARY.PRIMOP_BIND# IS 'Binding number of primary operator'
/

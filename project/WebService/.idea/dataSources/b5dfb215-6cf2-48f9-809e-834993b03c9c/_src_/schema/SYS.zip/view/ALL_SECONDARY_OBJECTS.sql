CREATE VIEW ALL_SECONDARY_OBJECTS AS select u.name, o.name, u1.name, o1.name, decode(s.spare1, 0, 'FROM INDEXTYPE',
                                                1, 'FROM STATISTICS TYPE')
from   sys.user$ u, sys.obj$ o, sys.user$ u1, sys.obj$ o1, sys.secobj$ s
where  s.obj# = o.obj# and o.owner# = u.user# and
       s.secobj# = o1.obj#  and  o1.owner# = u1.user# and
       ( o.owner# = userenv('SCHEMAID')
         or
         o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
         or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/
COMMENT ON VIEW SYS.ALL_SECONDARY_OBJECTS IS 'All secondary objects for domain indexes'
/
COMMENT ON COLUMN SYS.ALL_SECONDARY_OBJECTS.INDEX_OWNER IS 'Name of the domain index owner'
/
COMMENT ON COLUMN SYS.ALL_SECONDARY_OBJECTS.INDEX_NAME IS 'Name of the domain index'
/
COMMENT ON COLUMN SYS.ALL_SECONDARY_OBJECTS.SECONDARY_OBJECT_OWNER IS 'Owner of the secondary object'
/
COMMENT ON COLUMN SYS.ALL_SECONDARY_OBJECTS.SECONDARY_OBJECT_NAME IS 'Name of the secondary object'
/
COMMENT ON COLUMN SYS.ALL_SECONDARY_OBJECTS.SECONDARY_OBJDATA_TYPE IS 'Type of the secondary object'
/

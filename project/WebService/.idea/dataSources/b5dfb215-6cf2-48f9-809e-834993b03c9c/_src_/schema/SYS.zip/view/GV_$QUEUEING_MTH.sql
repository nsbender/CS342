CREATE VIEW GV_$QUEUEING_MTH AS select "INST_ID","NAME" from gv$queueing_mth
/

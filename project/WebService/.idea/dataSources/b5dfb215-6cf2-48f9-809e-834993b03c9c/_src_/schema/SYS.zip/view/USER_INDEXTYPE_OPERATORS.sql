CREATE VIEW USER_INDEXTYPE_OPERATORS AS select u.name, o.name, u1.name, op.name, i.bind#
from sys.user$ u, sys.indop$ i, sys.obj$ o,
sys.obj$ op, sys.user$ u1
where i.obj# = o.obj# and i.oper# = op.obj# and
      u.user# = o.owner# and u1.user#=op.owner# and
      o.owner# = userenv ('SCHEMAID') and bitand(i.property, 4) != 4
/
COMMENT ON VIEW SYS.USER_INDEXTYPE_OPERATORS IS 'All user indextype operators'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPE_OPERATORS.OWNER IS 'Owner of the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPE_OPERATORS.INDEXTYPE_NAME IS 'Name of the indextype'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPE_OPERATORS.OPERATOR_SCHEMA IS 'Name of the operator schema'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPE_OPERATORS.OPERATOR_NAME IS 'Name of the operator for which the indextype is defined'
/
COMMENT ON COLUMN SYS.USER_INDEXTYPE_OPERATORS.BINDING# IS 'Binding# associated with the operator'
/

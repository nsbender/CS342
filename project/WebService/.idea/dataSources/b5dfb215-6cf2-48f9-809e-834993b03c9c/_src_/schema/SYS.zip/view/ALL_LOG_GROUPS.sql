CREATE VIEW ALL_LOG_GROUPS AS select ou.name, oc.name, o.name,
       case c.type# when 14 then (case bitand(t.trigflag, 512)
                                  when 512 then 'EXTENDED PRIMARY KEY LOGGING'
                                  else 'PRIMARY KEY LOGGING'
                                  end)
                    when 15 then 'UNIQUE KEY LOGGING'
                    when 16 then 'FOREIGN KEY LOGGING'
                    when 17 then 'ALL COLUMN LOGGING'
                    else 'USER LOG GROUP'
       end,
       case bitand(c.defer,64) when 64 then 'ALWAYS'
                               else  'CONDITIONAL'
       end,
       case bitand(c.defer,8) when 8 then 'GENERATED NAME'
                              else  'USER NAME'
       end
from sys.con$ oc,  sys.user$ ou,
     sys.obj$ o, sys.cdef$ c, sys.tab$ t
where oc.owner# = ou.user#
  and oc.con# = c.con#
  and c.obj# = o.obj#
  and o.obj# = t.obj#
  and
  (c.type# = 12 or c.type# = 14 or
   c.type# = 15 or c.type# = 16 or
   c.type# = 17)
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in (select obj#
                     from sys.objauth$
                     where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                    )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
/
COMMENT ON VIEW SYS.ALL_LOG_GROUPS IS 'Log group definitions on accessible tables'
/
COMMENT ON COLUMN SYS.ALL_LOG_GROUPS.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.ALL_LOG_GROUPS.LOG_GROUP_NAME IS 'Name associated with log group definition'
/
COMMENT ON COLUMN SYS.ALL_LOG_GROUPS.ALWAYS IS 'Is this an ALWAYS or a CONDITIONAL supplemental log group?'
/
COMMENT ON COLUMN SYS.ALL_LOG_GROUPS.GENERATED IS 'Was the name of this supplemental log group system generated?'
/

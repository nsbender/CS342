CREATE VIEW EXU9EIP AS SELECT  o$.obj#, ip$.bo#, o$.owner#, o$.subname, ip$.part#,
                idpp$.parameters
        FROM    sys.obj$ o$, sys.indpart$ ip$, sys.indpart_param$ idpp$
        WHERE   o$.type# = 20 AND                       /* Partitioned Index */
                ip$.obj# = o$.obj# AND
                idpp$.obj# = o$.obj# AND
                (UID IN (0, o$.owner#) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/
